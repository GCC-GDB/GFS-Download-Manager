import tkinter as tk
from tkinter import filedialog
import os
import threading
import pygame
from pygame import mixer
import time

# 初始化 pygame 音频系统（确保线程安全）
pygame.init()
mixer.init()  # 初始化音频混合器
# 设置默认音频格式（提升兼容性）
mixer.pre_init(frequency=44100, size=-16, channels=2, buffer=512)

# 全局变量：跟踪当前播放线程（避免多线程冲突）
current_play_thread = None

def start():
    print('booting......')
    time.sleep(0.25)
    print('booting......')
    time.sleep(0.25)
    print('booting......')
    time.sleep(0.25)
md
print('软件名:Sound Player')
print('开发者：未知')


def stop_current_playback():
    """停止当前正在播放的音频（线程安全）"""
    if mixer.music.get_busy():
        mixer.music.stop()
    global current_play_thread
    current_play_thread = None


def play_audio(file_path):
    """音频播放线程函数（处理播放逻辑）"""
    global current_play_thread
    try:
        # 加载音频文件（支持 mp3, wav, ogg, m4a 等常见格式）
        mixer.music.load(file_path)
        print("开始播放：{}".format(os.path.basename(file_path)))

        # 开始播放（-1 表示循环播放，0 表示单次播放）
        mixer.music.play(0)

        # 循环检测播放状态，直到播放结束
        while mixer.music.get_busy():
            # 降低 CPU 占用（每 100ms 检测一次）
            pygame.time.delay(100)

        print("播放完成：{}".format(os.path.basename(file_path)))

    except pygame.error as e:
        # 捕获 pygame 音频相关错误（如格式不支持、文件损坏）
        print("播放失败：音频格式不支持或文件损坏 - {}".format(str(e)))
    except Exception as e:
        print("播放失败：{}".format(str(e)))
    finally:
        # 播放结束后重置当前线程状态
        current_play_thread = None


def main():
    # 隐藏 tkinter 主窗口（仅用文件选择对话框）
    root = tk.Tk()
    root.withdraw()
    os.system('title Pygame Sound Player)')  # 设置窗口标题
    start()
    
    while True:
        # 清屏（跨平台兼容）
        
        os.system('cls' if os.name == 'nt' else 'clear')

        # 显示菜单
        print("===== 音频播放器 =====")
        print("1. 播放新音频（会停止当前播放）")
        print("2. 停止当前播放")
        print("3. 退出程序")
        choice = input("请输入选项 (1/2/3)：")

        if choice == '1':
            # 停止当前播放（避免多线程冲突）
            stop_current_playback()

            # 选择音频文件
            file_path = filedialog.askopenfilename(
                title="选择音频文件",
                filetypes=[
                    ("支持的音频文件", "*.mp3 *.wav *.ogg *.m4a *.flac"),
                    ("MP3 文件", "*.mp3"),
                    ("WAV 文件", "*.wav"),
                    ("OGG 文件", "*.ogg"),
                    ("M4A 文件", "*.m4a"),
                    ("FLAC 文件", "*.flac")
                ]
            )

            # 检查文件是否有效
            if not file_path or not os.path.isfile(file_path):
                print("未选择有效文件，返回菜单")
                input("按回车键继续...")
                continue

            # 启动播放线程
            global current_play_thread
            current_play_thread = threading.Thread(
                target=play_audio,
                args=(file_path,),
                daemon=True  # 主线程退出时自动结束
            )
            current_play_thread.start()
            input("按回车键返回菜单（播放不会停止）")

        elif choice == '2':
            # 停止当前播放
            stop_current_playback()
            print("已停止当前播放")
            input("按回车键继续...")

        elif choice == '3':
            # 退出程序（释放资源）
            stop_current_playback()
            mixer.quit()  # 关闭音频混合器
            pygame.quit()  # 关闭 pygame
            print("程序退出中.....")
            time.sleep(2)
            break

        else:
            print("无效选项，请输入 1/2/3"

    
    



main()
