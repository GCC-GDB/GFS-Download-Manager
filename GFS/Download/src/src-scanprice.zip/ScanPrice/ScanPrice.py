import ttkbootstrap as ttkb
from tkinter import messagebox as msgbox
from tkinter import*
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import sys
import os
import time
import shutil
from datetime import datetime, timedelta
import pandas as pd
from ChartOfQuestion import GraphicUserInterFace

os.environ["QT_API"] = "none"
os.environ.pop("QT_QPA_PLATFORM", None)
# 强制matplotlib用tk后端，适配ttkbootstrap
os.environ["MPLBACKEND"] = "TkAgg"

def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

# 切换工作目录
target_dir = get_script_dir()
os.chdir(target_dir)
current_dir = os.getcwd()
root = ttkb.Window(themename="flatly")
root.withdraw()

# 修复matplotlib中文显示


# ========== 全局工具函数（数据库管理） ==========
def init_database():
    """初始化数据库目录结构"""
    dirs = [
        os.path.join(current_dir, "database"),
        os.path.join(current_dir, "database", "assets"),
        os.path.join(current_dir, "database", "backup"),
        os.path.join(current_dir, "database", "archive")
    ]
    for dir_path in dirs:
        os.makedirs(dir_path, exist_ok=True)

def backup_database(backup_days=30):
    """
    备份数据库
    :param backup_days: 保留备份的天数，超过自动删除
    """
    try:
        # 创建备份文件名
        backup_time = time.strftime("%Y%m%d_%H%M%S")
        backup_dir = os.path.join(current_dir, "database", "backup", f"backup_{backup_time}")
        # 复制整个database目录
        shutil.copytree(os.path.join(current_dir, "database"), backup_dir, ignore=shutil.ignore_patterns('backup', 'archive'))
        
        # 清理过期备份
        backup_root = os.path.join(current_dir, "database", "backup")
        for item in os.listdir(backup_root):
            item_path = os.path.join(backup_root, item)
            if os.path.isdir(item_path) and item.startswith("backup_"):
                # 解析备份时间
                try:
                    backup_date = datetime.strptime(item.split("_")[1], "%Y%m%d")
                    if datetime.now() - backup_date > timedelta(days=backup_days):
                        shutil.rmtree(item_path)
                except:
                    continue
        
        msgbox.showinfo("成功", "数据库备份完成！")
    except Exception as e:
        msgbox.showerror("错误", f"备份失败：{str(e)}")

def archive_old_data(archive_months=6):
    """
    归档旧数据（超过指定月份的移到归档目录）
    :param archive_months: 归档超过N个月的数据
    """
    try:
        db_path = os.path.join(current_dir, "database")
        archive_dir = os.path.join(db_path, "archive")
        
        # 获取当前年月
        current_year_month = datetime.now().strftime("%Y-%m")
        current_year, current_month = map(int, current_year_month.split("-"))
        
        # 遍历所有年月文件夹
        for item in os.listdir(db_path):
            item_path = os.path.join(db_path, item)
            if os.path.isdir(item_path) and "-" in item and len(item) == 7:
                # 解析文件夹年月
                try:
                    year, month = map(int, item.split("-"))
                    # 计算月份差
                    month_diff = (current_year - year) * 12 + (current_month - month)
                    if month_diff > archive_months:
                        # 移到归档目录
                        archive_target = os.path.join(archive_dir, item)
                        if os.path.exists(archive_target):
                            shutil.rmtree(archive_target)
                        shutil.move(item_path, archive_target)
                except:
                    continue
        
        msgbox.showinfo("成功", "旧数据归档完成！")
    except Exception as e:
        msgbox.showerror("错误", f"归档失败：{str(e)}")

def clean_empty_files():
    """清理空文件"""
    try:
        db_path = os.path.join(current_dir, "database")
        for root_dir, dirs, files in os.walk(db_path):
            for file in files:
                file_path = os.path.join(root_dir, file)
                if os.path.getsize(file_path) == 0:
                    os.remove(file_path)
        msgbox.showinfo("成功", "空文件清理完成！")
    except Exception as e:
        msgbox.showerror("错误", f"清理空文件失败：{str(e)}")

class Login:
    def __init__(self):
        self.root = ttkb.Toplevel()
        self.root.title("ScanPaice")
        self.root.geometry("960x680")
        self.root.place_window_center()

        # 布局配置 
        for i in range(34):
            self.root.rowconfigure(index=i, weight=1)
        for i in range(48):
            self.root.columnconfigure(index=i, weight=1)

        # 界面元素
        label = ttkb.Label(self.root, text="登录", font=("微软雅黑", 20, "bold"))
        label.place(x=440, y=100)

        ttkb.Label(self.root, text="用户名:", font=("微软雅黑",10,"normal")).place(x=285, y=205)
        self.username_entry = ttkb.Entry(self.root, width=50)
        self.username_entry.place(x=360, y=200)

        ttkb.Label(self.root, text="密码:", font=("微软雅黑",10,"normal")).place(x=285, y=250)
        self.password_entry = ttkb.Entry(self.root, width=50, show="●")
        self.password_entry.place(x=360, y=250)

        ttkb.Button(self.root, bootstyle="success-outline", width=7, text="登录", command=self.logon).place(x=360, y=400)
        ttkb.Button(self.root, bootstyle="danger-outline", width=7, text="清空", command=self.clear).place(x=540, y=400)

        # 正确的主题菜单实现代码
        self.Menubar = ttkb.Menu(self.root, tearoff=0)
        self.theme_menu = ttkb.Menu(self.Menubar, tearoff=0)

        # 错误1：ttkb.Style 缺少括号（没有创建实例）
        x = ttkb.Style()  # 修复：添加()创建Style实例

        # 遍历所有主题
        for i in x.theme_names():
            # 错误2：lambda中使用i会导致闭包陷阱，所有命令都指向最后一个主题
            # 错误3：root.config 使用全局root，应该使用self.root（当前窗口）
            self.theme_menu.add_command(
                label=i,
                command=lambda t=i:x.theme_use(t)# 修复：使用t=i传参 + self.root
            )

        self.Menubar.add_cascade(label="主题(T)", menu=self.theme_menu)
        self.root.config(menu=self.Menubar)
        
        self.root.mainloop()

    def logon(self):
        usr = self.username_entry.get()
        pwd = self.password_entry.get()
        if usr == "root" and pwd == "root123":
            msgbox.showinfo("success", "登录成功")
            self.root.withdraw()
            MST()
        else:
            msgbox.showerror("password incorrent", "密码不正确，请重试")
    
    def clear(self):
        self.password_entry.delete(0, END)
        self.username_entry.delete(0, END)

mouth_in_days = {
    "2": 29 if (int(time.strftime("%Y")) % 4 == 0 and int(time.strftime("%Y")) % 100 != 0) or (int(time.strftime("%Y")) % 400 == 0) else 28,
    "4": 30, "6": 30, "9": 30, "11": 30,
    "1": 31, "3": 31, "5": 31, "7": 31, "8": 31, "10": 31, "12": 31,
}

class MST():
    def __init__(self):
        # 初始化数据库目录
        init_database()
        
        self.root = ttkb.Toplevel()
        self.root.title("ScanPaice")
        self.root.geometry("1280x720")
        self.root.protocol("WM_DELETE_WINDOW",self.qut)
        
        self.date_var = ttkb.StringVar(value=time.strftime("%Y-%m"))
        self.date_var.trace('w', self.on_date_change)  # 监听年月切换

        # 初始化日志列表
        self.contant_logs = []
        self.money_logs = []
        self.time_logs = []
        self.type_logs = []
        self.total_budget = 0

        # 初始化界面
        self.init_ui()
        # 加载数据
        self.load_data()
        # 绘制图表
        self.draw_charts()
        # 填充表格
        self.fill_table()

        self.root.mainloop()

    def init_ui(self):
        """初始化界面布局"""
        
        self.menubar = ttkb.Menu(self.root,tearoff=0)
        
        self.tool_menu = ttkb.Menu(self.menubar,tearoff=0)
        self.tool_menu.add_command(label="ChartOfQuestion",command=self.boot_coq)
        self.menubar.add_cascade(label="工具(T)",menu=self.tool_menu)
        self.root.config(menu=self.menubar)
        
        # ========== 1. 统计收支标签页（带滚动条） ==========
        self.cha_lf = ttkb.Labelframe(self.root, text="统计收支", bootstyle="info", height=720-420)
        self.cha_lf.pack(anchor="nw", fill=X)
        self.cha_lf.pack_propagate(False)

        # 1.1 创建Canvas作为滚动容器
        cha_canvas = Canvas(self.cha_lf, bg="white", highlightthickness=0)
        cha_canvas.pack(side=LEFT, fill=BOTH, expand=True)

        # 1.2 创建垂直滚动条
        cha_scroll = ttkb.Scrollbar(self.cha_lf, orient=VERTICAL, command=cha_canvas.yview)
        cha_scroll.pack(side=RIGHT, fill=Y)
        cha_canvas.configure(yscrollcommand=cha_scroll.set)
    
        # 1.3 创建水平滚动条
        
        # 1.4 创建Frame放入Canvas
        self.cha_frame = Frame(cha_canvas, bg="white")
        cha_canvas.create_window((0, 0), window=self.cha_frame, anchor="nw")
        cha_canvas.config(scrollregion=cha_canvas.bbox("all"))

        # ========== 2. 支出记录标签页（带滚动条） ==========
        self.payd_lf = ttkb.Labelframe(self.root, text="支出记录", bootstyle="warning", width=768, height=420)
        self.payd_lf.pack(side=LEFT, anchor="sw")
        self.payd_lf.pack_propagate(False)

        # 2.1 创建滚动容器
        payd_canvas = Canvas(self.payd_lf, bg="white", highlightthickness=0)
        payd_scroll = ttkb.Scrollbar(self.payd_lf, orient=VERTICAL, command=payd_canvas.yview)
        payd_canvas.configure(yscrollcommand=payd_scroll.set)
        
        payd_canvas.pack(side=LEFT, fill=BOTH, expand=True)
        payd_scroll.pack(side=RIGHT, fill=Y)

        # 2.2 创建表格Frame
        payd_frame = Frame(payd_canvas, bg="white")
        payd_canvas.create_window((0, 0), window=payd_frame, anchor="nw")

        # 2.3 创建Treeview表格
        self.payd_tree = ttkb.Treeview(
            payd_frame, height=20,
            columns=("id","time","type","contant","money"),
            show="headings"
        )

        # 表头和列宽
        self.payd_tree.heading("id", text="序号")
        self.payd_tree.heading("time", text="时间")
        self.payd_tree.heading("type", text="类型")
        self.payd_tree.heading("contant", text="内容")
        self.payd_tree.heading("money", text="金额")

        self.payd_tree.column("id", width=50, anchor="center")
        self.payd_tree.column("time", width=190, anchor="center")
        self.payd_tree.column("type", width=100, anchor="center")
        self.payd_tree.column("contant", width=300, anchor="center")
        self.payd_tree.column("money", width=100, anchor="center")

        self.payd_tree.pack(fill=BOTH, expand=True)
        payd_frame.update_idletasks()
        payd_canvas.config(scrollregion=payd_canvas.bbox("all"))

        # ========== 3. 操作标签页 ==========
        self.opet_lf = ttkb.Labelframe(self.root, text="操作", bootstyle="success", width=1280-768, height=420)
        self.opet_lf.pack(anchor="se")
        self.opet_lf.pack_propagate(False)

        # 3.1 年月选择
        self.load_date_options()
        self.date_om = ttkb.OptionMenu(
            self.opet_lf,
            self.date_var,
            self.date_var.get(),
            *self.date_options,
            bootstyle="primary-outline"
        )
        self.date_om.config(width=15)
        self.date_om.place(x=50, y=50)

        # 3.2 功能按钮
        ttkb.Button(self.opet_lf,text="添加支出",command=self.open_add_expense,bootstyle="success-outline").place(x = 50,y = 100)
        ttkb.Button(self.opet_lf,text="删除支出",command=self.delete_expense,bootstyle="warning-outline").place(x = 50,y = 150)
        ttkb.Button(self.opet_lf,text="添加资产",command=self.open_add_asset,bootstyle="success-outline").place(x = 50,y = 200)
        ttkb.Button(self.opet_lf,text="备份数据库",command=lambda: backup_database(30),bootstyle="info-outline").place(x = 50,y = 250)
        ttkb.Button(self.opet_lf,text="归档旧数据",command=lambda: archive_old_data(6),bootstyle="info-outline").place(x = 50,y = 300)
        ttkb.Button(self.opet_lf,text="清理空文件",command=clean_empty_files,bootstyle="danger-outline").place(x = 50,y = 350)

        
        ttkb.Button(self.opet_lf,text="月度计算设置",command=self.open_1,bootstyle="info-outline").place(x = 350,y = 100)
        ttkb.Button(self.opet_lf,text="数据导入/导出",command=self.open_2,bootstyle="info-outline").place(x = 350,y = 150)

        # 正确的主题菜单实现代码
        
        # 错误1：ttkb.Style 缺少括号（没有创建实例）
        x = ttkb.Style()  # 修复：添加()创建Style实例

        # 遍历所有主题
    
    def qut(self):
        sys.exit()
        
    def load_date_options(self):
        """加载年月选项"""
        self.date_options = [time.strftime("%Y-%m")]
        db_path = os.path.join(current_dir, "database")
        for item in os.listdir(db_path):
            if os.path.isdir(os.path.join(db_path, item)) and "-" in item and len(item) == 7:
                if item not in self.date_options:
                    self.date_options.append(item)

    def load_data(self):
        """加载当前年月的数据"""
        try:
            month_dir = os.path.join(current_dir,"database",self.date_var.get())
            os.makedirs(month_dir, exist_ok=True)
            
            # 读取支出数据
            files = {
                "content": os.path.join(month_dir,"payd_content.sys"),
                "money": os.path.join(month_dir,"payd_money.sys"),
                "time": os.path.join(month_dir,"payd_time.sys"),
                "type": os.path.join(month_dir,"payd_type.sys"),
                "settings": os.path.join(month_dir,"settings.sys")
            }
            
            # 初始化文件（如果不存在）
            """
            for file_path in files.values():
                if not os.path.exists(file_path):
                    with open(file_path, "w", encoding="utf-8") as f:
                        if "settings" in file_path:
                            f.write("10000\n")  # 默认预算10000元
                        else:
                            f.write("")
            """
            
            # 读取数据
            with open(files["content"],"r",encoding="utf-8",errors="ignore") as f:
                self.contant_logs = f.read().splitlines()
            with open(files["money"],"r",encoding="utf-8",errors="ignore") as f:
                self.money_logs = f.read().splitlines()
            with open(files["time"],"r",encoding="utf-8",errors="ignore") as f:
                self.time_logs = f.read().splitlines()
            with open(files["type"],"r",encoding="utf-8",errors="ignore") as f:
                self.type_logs = f.read().splitlines()
            with open(files["settings"],"r",encoding="utf-8",errors="ignore") as f:
                settings = f.read().splitlines()
                self.total_budget = int(settings[0]) if settings else 10000
                
        except Exception as e:
            msgbox.showwarning("注意",f"文件读取错误：{str(e)}，自动创建新文件")
            with open(files["content"],"w",encoding="utf-8",errors="ignore") as f:
                f.write("")
            with open(files["money"],"w",encoding="utf-8",errors="ignore") as f:
                f.write("")
            with open(files["time"],"w",encoding="utf-8",errors="ignore") as f:
                f.write("")
            with open(files["type"],"w",encoding="utf-8",errors="ignore") as f:
                f.write("")
            with open(files["settings"],"w",encoding="utf-8",errors="ignore") as f:
                f.write("3000")
                
            self.contant_logs, self.money_logs, self.time_logs, self.type_logs = [], [], [], []
            self.total_budget = 10000

    def boot_coq(self):
        GraphicUserInterFace()
        
    def draw_charts(self):
        """绘制图表"""
        # 清空旧图表
        for widget in self.cha_frame.winfo_children():
            widget.destroy()
        
        # 计算支出占比
        result = self.option_all_types()
        va1, va2, bar_va1, bar_va2 = [], [], [], []
        
        for type_name, type_money in result:
            if self.total_budget > 0:
                percentage = round(type_money / self.total_budget * 100, 1)
            else:
                percentage = 0
            va1.append(type_name)
            va2.append(percentage)
            bar_va1.append(type_name)
            bar_va2.append(type_money)

        # 计算剩余预算
        used_percentage_sum = sum(va2)
        remaining_percentage = round(100 - used_percentage_sum, 1)
        va1.append("剩余")
        va2.append(remaining_percentage)

        # 绘制图表
        if va2:
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15,5), dpi=80)
            
            # 饼图
            wedges, texts, autotexts = ax1.pie(
                va2, labels=va1, autopct='%1.1f%%',
                labeldistance=1.2, pctdistance=0.8,
                textprops={'fontsize': 9, 'fontfamily': 'Microsoft YaHei'},
                startangle=90, wedgeprops={'width': 0.8}
            )
            for autotext in autotexts:
                autotext.set_color('white')
                autotext.set_fontweight('bold')
            ax1.set_title("支出占比", fontsize=12, pad=10, fontfamily='Microsoft YaHei')

            # 柱状图
            if bar_va2:
                bars = ax2.bar(range(len(bar_va2)), height=bar_va2, width=0.5, color='skyblue')
                ax2.set_title("支出金额统计", fontsize=12, fontfamily='Microsoft YaHei')
                ax2.set_xticks(range(len(bar_va1)))
                ax2.set_xticklabels(bar_va1, rotation=15, fontsize=9, fontfamily='Microsoft YaHei')
                for bar in bars:
                    height = bar.get_height()
                    ax2.text(bar.get_x() + bar.get_width()/2, height + 5, 
                            f"{height:.0f}", ha='center', va='bottom', fontsize=9, fontfamily='Microsoft YaHei')
                ax2.set_ylim(0, max(bar_va2) * 1.1)
                ax2.set_ylabel("金额（元）", fontfamily='Microsoft YaHei')
            
            plt.tight_layout()
            canvas = FigureCanvasTkAgg(fig, master=self.cha_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=BOTH, expand=True)
            
            # 更新滚动区域
            self.cha_frame.update_idletasks()
            cha_canvas = self.cha_lf.winfo_children()[0]
            cha_canvas.config(scrollregion=cha_canvas.bbox("all"))

    def fill_table(self):
        """填充表格"""
        # 清空表格
        self.payd_tree.delete(*self.payd_tree.get_children())
        
        # 填充数据
        max_len = min(len(self.time_logs), len(self.type_logs), len(self.contant_logs), len(self.money_logs))
        for idx in range(max_len):
            seq = idx + 1
            time_val = self.time_logs[idx].strip() if idx < len(self.time_logs) else ""
            type_val = self.type_logs[idx].strip() if idx < len(self.type_logs) else ""
            content_val = self.contant_logs[idx].strip() if idx < len(self.contant_logs) else ""
            try:
                money_val = round(float(self.money_logs[idx].strip()), 2) if idx < len(self.money_logs) else 0.00
            except:
                money_val = 0.00
            self.payd_tree.insert("", END, values=(seq, time_val, type_val, content_val, money_val))

    def on_date_change(self, *args):
        """年月切换回调"""
        self.load_data()
        self.draw_charts()
        self.fill_table()

    def option_all_types(self):
        """统计各类型支出"""
        output_2 = {}
        for type_name, money_str in zip(self.type_logs, self.money_logs):
            if not type_name.strip() or not money_str.strip():
                continue
            try:
                money = float(money_str)
            except ValueError:
                money = 0.0
            if type_name not in output_2:
                output_2[type_name] = []
            output_2[type_name].append(money)
        return [(k, round(sum(v), 2)) for k, v in output_2.items()]

    def open_add_expense(self):
        """打开添加支出窗口"""
        AddExpenseWindow(self.root, self.date_var.get(), self.refresh_data)

    def open_add_asset(self):
        """打开添加资产窗口"""
        AssetAddWindow(self.root, self.refresh_data)

    def delete_expense(self):
        """删除支出记录"""
        selected = self.payd_tree.selection()
        if not selected:
            msgbox.showwarning("提示", "请先选中要删除的支出记录！")
            return
        
        if not msgbox.askyesno("确认", "确定要删除选中的支出记录吗？"):
            return
        
        try:
            # 获取选中行的索引
            item = self.payd_tree.item(selected[0])
            seq = int(item['values'][0]) - 1  # 转成0索引
            
            # 删除内存中的数据
            if 0 <= seq < len(self.contant_logs):
                del self.contant_logs[seq]
                del self.money_logs[seq]
                del self.time_logs[seq]
                del self.type_logs[seq]
            
            # 删除界面数据
            self.payd_tree.delete(selected)
            
            # 保存到文件
            self.save_expense_data()
            
            # 刷新界面
            self.refresh_data()
            
            msgbox.showinfo("成功", "支出记录删除成功！")
        except Exception as e:
            msgbox.showerror("错误", f"删除失败：{str(e)}")

    def save_expense_data(self):
        """保存支出数据到文件"""
        month_dir = os.path.join(current_dir,"database",self.date_var.get())
        os.makedirs(month_dir, exist_ok=True)
        
        # 写入文件
        with open(os.path.join(month_dir,"payd_content.sys"),"w",encoding="utf-8") as f:
            f.write("\n".join(self.contant_logs))
        with open(os.path.join(month_dir,"payd_money.sys"),"w",encoding="utf-8") as f:
            f.write("\n".join(self.money_logs))
        with open(os.path.join(month_dir,"payd_time.sys"),"w",encoding="utf-8") as f:
            f.write("\n".join(self.time_logs))
        with open(os.path.join(month_dir,"payd_type.sys"),"w",encoding="utf-8") as f:
            f.write("\n".join(self.type_logs))

    def refresh_data(self):
        """刷新所有数据和界面"""
        self.load_data()
        self.draw_charts()
        self.fill_table()
    
    def open_1(self):
        """打开预算设置窗口"""
        BudgetSettingWindow(self.root, self.date_var.get(), self.total_budget, self.refresh_data)

    def open_2(self):
        """打开数据导出窗口"""
        expense_data = (self.contant_logs, self.money_logs, self.time_logs, self.type_logs)
        DataExportImportWindow(self.root, self.date_var.get(), expense_data)

# ========== 添加支出窗口 ==========
class AddExpenseWindow:
    def __init__(self, parent, current_month, refresh_callback):
        self.parent = parent
        self.current_month = current_month
        self.refresh_callback = refresh_callback
        
        self.add_win = ttkb.Toplevel(parent)
        self.add_win.title("添加支出记录")
        self.add_win.geometry("768x450")  # 调整窗口高度适配新控件
        self.add_win.place_window_center()
        
        # 界面布局
        title_label = ttkb.Label(self.add_win, text="添加支出", font=("微软雅黑", 18, "bold"), bootstyle="primary")
        title_label.pack(pady=20)
        
        main_frame = ttkb.Frame(self.add_win, padding=20)
        main_frame.pack(fill="both", expand=True)
        
        # 1. 支出类型
        ttkb.Label(main_frame, text="支出类型：", font=("微软雅黑", 12)).grid(row=0, column=0, sticky="w", pady=10)
        self.expense_type_var = ttkb.StringVar()
        expense_types = ["餐饮", "交通", "购物", "娱乐", "房租", "水电", "通讯", "医疗", "学习", "其他"]
        type_combobox = ttkb.Combobox(
            main_frame, 
            textvariable=self.expense_type_var,
            values=expense_types,
            font=("微软雅黑", 11),
            state="readonly",
            width=30
        )
        type_combobox.grid(row=0, column=1, padx=10, pady=10)
        type_combobox.current(0)
        
        # 2. 支出金额
        ttkb.Label(main_frame, text="支出金额（元）：", font=("微软雅黑", 12)).grid(row=1, column=0, sticky="w", pady=10)
        self.money_var = ttkb.StringVar()
        money_entry = ttkb.Entry(main_frame, textvariable=self.money_var, font=("微软雅黑", 11), width=32)
        money_entry.grid(row=1, column=1, padx=10, pady=10)
        
        # 3. 支出备注
        ttkb.Label(main_frame, text="支出备注：", font=("微软雅黑", 12)).grid(row=2, column=0, sticky="w", pady=10)
        self.note_var = ttkb.StringVar()
        note_entry = ttkb.Entry(main_frame, textvariable=self.note_var, font=("微软雅黑", 11), width=32)
        note_entry.grid(row=2, column=1, padx=10, pady=10)
        
        # 4. 支出时间 - 日期 + 时分秒（Spinbox实现）
        ttkb.Label(main_frame, text="支出时间：", font=("微软雅黑", 12)).grid(row=3, column=0, sticky="w", pady=10)
        
        # 4.1 日期选择
        self.date_entry = ttkb.DateEntry(
            main_frame,
            width=18,
            dateformat="%Y-%m-%d"
        )
        self.date_entry.set_date(datetime.now().date())
        self.date_entry.grid(row=3, column=1, padx=5, pady=10, sticky="w")
        
        # 4.2 时分秒 Spinbox
        # 获取当前时间的时分秒初始值
        now = datetime.now()
        self.hour_var = ttkb.StringVar(value=f"{now.hour:02d}")
        self.minute_var = ttkb.StringVar(value=f"{now.minute:02d}")
        self.second_var = ttkb.StringVar(value=f"{now.second:02d}")
        
        # 小时Spinbox（0-23）
        hour_spin = ttkb.Spinbox(
            main_frame,
            textvariable=self.hour_var,
            width=4,
            from_=0,
            to=23,
            font=("微软雅黑", 11),
            wrap=True  # 循环滚动
        )
        hour_spin.grid(row=3, column=1, padx=200, pady=10, sticky="w")
        
        # 分隔符
        ttkb.Label(main_frame, text=":", font=("微软雅黑", 11)).grid(row=3, column=1, padx=285, pady=10, sticky="w")
        
        # 分钟Spinbox（0-59）
        minute_spin = ttkb.Spinbox(
            main_frame,
            textvariable=self.minute_var,
            width=4,
            from_=0,
            to=59,
            font=("微软雅黑", 11),
            wrap=True
        )
        minute_spin.grid(row=3, column=1, padx=300, pady=10, sticky="w")
        
        # 分隔符
        ttkb.Label(main_frame, text=":", font=("微软雅黑", 11)).grid(row=3, column=1, padx=385, pady=10, sticky="w")
        
        # 秒Spinbox（0-59）
        second_spin = ttkb.Spinbox(
            main_frame,
            textvariable=self.second_var,
            width=4,
            from_=0,
            to=59,
            font=("微软雅黑", 11),
            wrap=True
        )
        second_spin.grid(row=3, column=1, padx=400, pady=10, sticky="w")
        
        # 5. 按钮（调整行号避免布局冲突）
        btn_frame = ttkb.Frame(main_frame)
        btn_frame.grid(row=4, column=0, columnspan=2, pady=30)
        
        ttkb.Button(btn_frame, text="确认添加", bootstyle="success-outline", width=15, command=self.save_expense).pack(side="left", padx=10)
        ttkb.Button(btn_frame, text="清空输入", bootstyle="warning-outline", width=15, command=self.clear_input).pack(side="left", padx=10)
        ttkb.Button(btn_frame, text="关闭窗口", bootstyle="danger-outline", width=15, command=self.add_win.destroy).pack(side="left", padx=10)

    def validate_input(self):
        """验证输入"""
        if not self.expense_type_var.get():
            msgbox.showerror("错误", "请选择支出类型！")
            return False
        
        try:
            money = float(self.money_var.get())
            if money <= 0:
                msgbox.showerror("错误", "支出金额必须大于0！")
                return False
        except ValueError:
            msgbox.showerror("错误", "请输入有效的数字金额！")
            return False
        
        return True

    def save_expense(self):
        """保存支出记录"""
        if not self.validate_input():
            return
        
        # 准备数据
        expense_type = self.expense_type_var.get()
        money = round(float(self.money_var.get()), 2)
        note = self.note_var.get() or "无备注"
        
        # 拼接日期和时分秒（修复核心错误）
        selected_date = self.date_entry.get_date()  # 获取日期对象
        # 补零处理，确保格式为 00:00:00
        hour = self.hour_var.get().zfill(2)
        minute = self.minute_var.get().zfill(2)
        second = self.second_var.get().zfill(2)
        # 拼接完整时间字符串
        record_time = f"{selected_date} {hour}:{minute}:{second}"

        print(f"保存的时间：{record_time}")
        
        # 保存到文件
        try:
            month_dir = os.path.join(current_dir,"database",self.current_month)
            os.makedirs(month_dir, exist_ok=True)
            
            # 追加写入
            with open(os.path.join(month_dir,"payd_content.sys"),"a",encoding="utf-8") as f:
                f.write(f"{note}\n")
            with open(os.path.join(month_dir,"payd_money.sys"),"a",encoding="utf-8") as f:
                f.write(f"{money}\n")
            with open(os.path.join(month_dir,"payd_time.sys"),"a",encoding="utf-8") as f:
                f.write(f"{record_time}\n")
            with open(os.path.join(month_dir,"payd_type.sys"),"a",encoding="utf-8") as f:
                f.write(f"{expense_type}\n")
            
            msgbox.showinfo("成功", "支出记录添加成功！")
            self.clear_input()
            
            # 刷新主界面
            if self.refresh_callback:
                self.refresh_callback()
                
        except Exception as e:
            msgbox.showerror("错误", f"保存失败：{str(e)}")

    def clear_input(self):
        """清空输入"""
        self.expense_type_var.set("餐饮")
        self.money_var.set("")
        self.note_var.set("")
        # 重置时间为当前时间
        now = datetime.now()
        self.date_entry.set_date(now.date())
        self.hour_var.set(f"{now.hour:02d}")
        self.minute_var.set(f"{now.minute:02d}")
        self.second_var.set(f"{now.second:02d}")


# ========== 添加资产窗口 ==========
class AssetAddWindow:
    def __init__(self, parent, refresh_callback=None):
        self.parent = parent
        self.refresh_callback = refresh_callback
        self.current_dir = get_script_dir()
        
        self.add_win = ttkb.Toplevel(parent)
        self.add_win.title("添加资产记录")
        self.add_win.geometry("600x500")
        self.add_win.resizable(False, False)
        self.add_win.place_window_center()
        
        # 界面布局
        title_label = ttkb.Label(self.add_win, text="添加资产", font=("微软雅黑", 18, "bold"), bootstyle="primary")
        title_label.pack(pady=20)
        
        main_frame = ttkb.Frame(self.add_win, padding=20)
        main_frame.pack(fill="both", expand=True)
        
        # 1. 资产类型
        ttkb.Label(main_frame, text="资产类型：", font=("微软雅黑", 12)).grid(row=0, column=0, sticky="w", pady=10)
        self.asset_type_var = ttkb.StringVar()
        asset_types = ["银行存款", "现金", "支付宝", "微信钱包", "股票", "基金", "房产", "车辆", "其他"]
        type_combobox = ttkb.Combobox(
            main_frame, 
            textvariable=self.asset_type_var,
            values=asset_types,
            font=("微软雅黑", 11),
            state="readonly",
            width=30
        )
        type_combobox.grid(row=0, column=1, padx=10, pady=10)
        type_combobox.current(0)
        
        # 2. 资产金额
        ttkb.Label(main_frame, text="资产金额（元）：", font=("微软雅黑", 12)).grid(row=1, column=0, sticky="w", pady=10)
        self.money_var = ttkb.StringVar()
        money_entry = ttkb.Entry(main_frame, textvariable=self.money_var, font=("微软雅黑", 11), width=32)
        money_entry.grid(row=1, column=1, padx=10, pady=10)
        
        # 3. 资产备注
        ttkb.Label(main_frame, text="资产名称/备注：", font=("微软雅黑", 12)).grid(row=2, column=0, sticky="w", pady=10)
        self.name_var = ttkb.StringVar()
        name_entry = ttkb.Entry(main_frame, textvariable=self.name_var, font=("微软雅黑", 11), width=32)
        name_entry.grid(row=2, column=1, padx=10, pady=10)
        
        # 4. 记录时间
        ttkb.Label(main_frame, text="时间：", font=("微软雅黑", 12)).grid(row=3, column=0, sticky="w", pady=10)
        
        # 4.1 日期选择
        self.date_entry = ttkb.DateEntry(
            main_frame,
            width=18,
            dateformat="%Y-%m-%d"
        )
        self.date_entry.set_date(datetime.now().date())
        self.date_entry.grid(row=3, column=1, padx=5, pady=10, sticky="w")
        
        # 4.2 时分秒 Spinbox
        # 获取当前时间的时分秒初始值
        now = datetime.now()
        self.hour_var = ttkb.StringVar(value=f"{now.hour:02d}")
        self.minute_var = ttkb.StringVar(value=f"{now.minute:02d}")
        self.second_var = ttkb.StringVar(value=f"{now.second:02d}")
        
        # 小时Spinbox（0-23）
        hour_spin = ttkb.Spinbox(
            main_frame,
            textvariable=self.hour_var,
            width=4,
            from_=0,
            to=23,
            font=("微软雅黑", 11),
            wrap=True  # 循环滚动
        )
        hour_spin.grid(row=3, column=1, padx=200, pady=10, sticky="w")
        
        # 分隔符
        ttkb.Label(main_frame, text=":", font=("微软雅黑", 11)).grid(row=3, column=1, padx=285, pady=10, sticky="w")
        
        # 分钟Spinbox（0-59）
        minute_spin = ttkb.Spinbox(
            main_frame,
            textvariable=self.minute_var,
            width=4,
            from_=0,
            to=59,
            font=("微软雅黑", 11),
            wrap=True
        )
        minute_spin.grid(row=3, column=1, padx=300, pady=10, sticky="w")
        
        # 分隔符
        ttkb.Label(main_frame, text=":", font=("微软雅黑", 11)).grid(row=3, column=1, padx=385, pady=10, sticky="w")
        
        # 秒Spinbox（0-59）
        second_spin = ttkb.Spinbox(
            main_frame,
            textvariable=self.second_var,
            width=4,
            from_=0,
            to=59,
            font=("微软雅黑", 11),
            wrap=True
        )
        second_spin.grid(row=3, column=1, padx=400, pady=10, sticky="w")
        
        
        # 5. 按钮
        btn_frame = ttkb.Frame(main_frame)
        btn_frame.grid(row=4, column=0, columnspan=3, pady=30)
        
        ttkb.Button(btn_frame, text="确认添加", bootstyle="success-outline", width=15, command=self.save_asset).pack(side="left", padx=20)
        ttkb.Button(btn_frame, text="清空输入", bootstyle="warning-outline", width=15, command=self.clear_input).pack(side="left", padx=20)
        ttkb.Button(btn_frame, text="关闭窗口", bootstyle="danger-outline", width=15, command=self.add_win.destroy).pack(side="left", padx=20)

    def validate_input(self):
        self.time_var = ttkb.StringVar(value=str(self.date_entry.get_date())+str(self.hour_var)+str(self.minute_var)+str(self.second_var))
        """验证输入"""
        if not self.asset_type_var.get():
            msgbox.showerror("输入错误", "请选择资产类型！")
            return False
        
        try:
            money = float(self.money_var.get())
            if money < 0:
                msgbox.showerror("输入错误", "资产金额不能为负数！")
                return False
        except ValueError:
            msgbox.showerror("输入错误", "请输入有效的数字金额！")
            return False
        
        if not self.name_var.get():
            if not msgbox.askyesno("提示", "未填写资产备注，是否继续？"):
                return False
        
        if len(self.time_var.get()) < 16:
            msgbox.showerror("输入错误", "时间格式不正确！")
            return False
        
        return True

    def save_asset(self):
        """保存资产数据"""
        if not self.validate_input():
            return
        
        # 准备数据
        asset_type = self.asset_type_var.get()
        money = round(float(self.money_var.get()), 2)
        name = self.name_var.get() or "无备注"
        record_time = self.time_var.get()
        
        # 保存到文件
        try:
            asset_dir = os.path.join(self.current_dir, "database", "assets")
            os.makedirs(asset_dir, exist_ok=True)
            
            year_month = time.strftime("%Y-%m")
            asset_file = os.path.join(asset_dir, f"assets_{year_month}.sys")
            
            with open(asset_file, "a", encoding="utf-8") as f:
                f.write(f"{record_time}|{asset_type}|{name}|{money}\n")
            
            msgbox.showinfo("成功", "资产记录添加成功！")
            self.clear_input()
            
            if self.refresh_callback:
                self.refresh_callback()
                
        except Exception as e:
            msgbox.showerror("错误", f"保存失败：{str(e)}")

    def clear_input(self):
        """清空输入"""
        self.asset_type_var.set("银行存款")
        self.money_var.set("")
        self.name_var.set("")
        self.time_var.set(time.strftime("%Y-%m-%d %H:%M:%S"))

# ========== 月度预算设置工具 ==========
class BudgetSettingWindow:
    def __init__(self, parent, current_month, current_budget, refresh_callback):
        """
        预算设置窗口
        :param parent: 父窗口
        :param current_month: 当前年月（如2026-03）
        :param current_budget: 当前预算值
        :param refresh_callback: 刷新主界面的回调
        """
        self.parent = parent
        self.current_month = current_month
        self.current_budget = current_budget
        self.refresh_callback = refresh_callback
        
        # 创建窗口
        self.budget_win = ttkb.Toplevel(parent)
        self.budget_win.title("设置月度预算")
        self.budget_win.geometry("400x250")
        self.budget_win.resizable(False, False)
        self.budget_win.place_window_center()
        
        # 界面布局
        main_frame = ttkb.Frame(self.budget_win, padding=30)
        main_frame.pack(fill="both", expand=True)
        
        # 1. 显示当前年月和预算
        ttkb.Label(
            main_frame, 
            text=f"当前年月：{self.current_month}", 
            font=("微软雅黑", 12)
        ).grid(row=0, column=0, columnspan=2, pady=10)
        
        ttkb.Label(
            main_frame, 
            text=f"当前预算：{self.current_budget} 元", 
            font=("微软雅黑", 12),
            bootstyle="primary"
        ).grid(row=1, column=0, columnspan=2, pady=10)
        
        # 2. 输入新预算
        ttkb.Label(main_frame, text="新预算金额：", font=("微软雅黑", 12)).grid(row=2, column=0, sticky="w", pady=10)
        self.new_budget_var = ttkb.StringVar(value=str(self.current_budget))
        budget_entry = ttkb.Entry(
            main_frame, 
            textvariable=self.new_budget_var,
            font=("微软雅黑", 11),
            width=20
        )
        budget_entry.grid(row=2, column=1, padx=10, pady=10)
        
        # 3. 按钮
        btn_frame = ttkb.Frame(main_frame)
        btn_frame.grid(row=3, column=0, columnspan=2, pady=20)
        
        ttkb.Button(
            btn_frame,
            text="保存预算",
            bootstyle="success-outline",
            width=12,
            command=self.save_budget
        ).pack(side="left", padx=10)
        
        ttkb.Button(
            btn_frame,
            text="取消",
            bootstyle="danger-outline",
            width=12,
            command=self.budget_win.destroy
        ).pack(side="left", padx=10)

    def save_budget(self):
        """保存新预算"""
        try:
            new_budget = int(self.new_budget_var.get())
            if new_budget <= 0:
                msgbox.showerror("错误", "预算金额必须大于0！")
                return
            
            # 保存到settings.sys文件
            month_dir = os.path.join(current_dir, "database", self.current_month)
            settings_file = os.path.join(month_dir, "settings.sys")
            
            with open(settings_file, "w", encoding="utf-8") as f:
                f.write(f"{new_budget}\n")
            
            msgbox.showinfo("成功", f"预算设置成功！\n{self.current_month} 月预算：{new_budget} 元")
            self.budget_win.destroy()
            
            # 刷新主界面
            if self.refresh_callback:
                self.refresh_callback()
                
        except ValueError:
            msgbox.showerror("错误", "请输入有效的数字！")
        except Exception as e:
            msgbox.showerror("错误", f"保存失败：{str(e)}")

# ========== 数据导出/导入工具 ==========



class DataExportImportWindow:
    def __init__(self, parent, current_month, expense_data):
        """
        数据导出/导入窗口
        :param parent: 父窗口
        :param current_month: 当前年月
        :param expense_data: 支出数据（content, money, time, type）
        """
        self.parent = parent
        self.current_month = current_month
        self.content_logs, self.money_logs, self.time_logs, self.type_logs = expense_data
        
        # 创建窗口
        self.data_win = ttkb.Toplevel(parent)
        self.data_win.title("数据导出/导入")
        self.data_win.geometry("500x300")
        self.data_win.resizable(False, False)
        self.data_win.place_window_center()
        
        # 界面布局
        main_frame = ttkb.Frame(self.data_win, padding=30)
        main_frame.pack(fill="both", expand=True)
        
        # 标题
        ttkb.Label(
            main_frame,
            text=f"{self.current_month} 数据管理",
            font=("微软雅黑", 16, "bold"),
            bootstyle="primary"
        ).pack(pady=20)
        
        # 按钮区域
        btn_frame = ttkb.Frame(main_frame)
        btn_frame.pack(fill="x", expand=True)
        
        # 1. 导出Excel
        ttkb.Button(
            btn_frame,
            text="导出为Excel",
            bootstyle="success-outline",
            width=20,
            command=self.export_to_excel
        ).pack(pady=10)
        
        # 2. 导出CSV
        ttkb.Button(
            btn_frame,
            text="导出为CSV",
            bootstyle="info-outline",
            width=20,
            command=self.export_to_csv
        ).pack(pady=10)
        
        # 3. 导入Excel（可选，如需导入功能取消注释）
        # ttkb.Button(
        #     btn_frame,
        #     text="从Excel导入",
        #     bootstyle="warning-outline",
        #     width=20,
        #     command=self.import_from_excel
        # ).pack(pady=10)

    def export_to_excel(self):
        """导出数据到Excel"""
        try:
            # 准备数据
            data = {
                "序号": list(range(1, len(self.content_logs)+1)),
                "时间": self.time_logs,
                "类型": self.type_logs,
                "内容": self.content_logs,
                "金额": self.money_logs
            }
            df = pd.DataFrame(data)
            
            # 保存路径
            save_path = os.path.join(
                current_dir,
                f"支出数据_{self.current_month}.xlsx"
            )
            
            # 导出Excel
            df.to_excel(save_path, index=False, engine="openpyxl")
            msgbox.showinfo("成功", f"Excel导出成功！\n文件路径：{save_path}")
            
        except Exception as e:
            msgbox.showerror("错误", f"导出失败：{str(e)}\n请先安装：pip install pandas openpyxl")

    def export_to_csv(self):
        """导出数据到CSV"""
        try:
            # 准备数据
            data = {
                "序号": list(range(1, len(self.content_logs)+1)),
                "时间": self.time_logs,
                "类型": self.type_logs,
                "内容": self.content_logs,
                "金额": self.money_logs
            }
            df = pd.DataFrame(data)
            
            # 保存路径
            save_path = os.path.join(
                current_dir,
                f"支出数据_{self.current_month}.csv"
            )
            
            # 导出CSV（指定编码，避免中文乱码）
            df.to_csv(save_path, index=False, encoding="utf-8-sig")
            msgbox.showinfo("成功", f"CSV导出成功！\n文件路径：{save_path}")
            
        except Exception as e:
            msgbox.showerror("错误", f"导出失败：{str(e)}\n请先安装：pip install pandas")

    # 如需导入功能，取消下面注释（需额外处理数据验证）
    # def import_from_excel(self):
    #     """从Excel导入数据"""
    #     from tkinter import filedialog
    #     file_path = filedialog.askopenfilename(
    #         title="选择Excel文件",
    #         filetypes=[("Excel文件", "*.xlsx *.xls"), ("所有文件", "*.*")]
    #     )
    #     if not file_path:
    #         return
        
    #     try:
    #         df = pd.read_excel(file_path)
    #         # 验证数据格式（省略，需根据你的字段验证）
    #         # 保存到文件（省略，参考添加支出的逻辑）
    #         msgbox.showinfo("成功", "数据导入成功！")
    #     except Exception as e:
    #         msgbox.showerror("错误", f"导入失败：{str(e)}")
# ========== 主程序 ==========
if __name__ == '__main__':
    app = Login()  # 如需登录，取消注释
    #Login()

    #x = MST()
    #AddExpenseWindow(x.root, x.date_var.get(), x.refresh_data)
    pass

