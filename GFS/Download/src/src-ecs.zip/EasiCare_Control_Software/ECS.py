import pyautogui
import time
import os
from tkinter import messagebox

# 防止操作过快，设置每个动作的间隔（秒）
pyautogui.PAUSE = 1.0

print("booting.............")
time.sleep(0.5)
print("booting.............")
time.sleep(0.5)
print("booting.............")
time.sleep(0.5)
print("booting.............")

print("\n软件名称：ECS(EasiNote Control Software)--班级优化大师控制软件")
print("开发者：未知")

time.sleep(0.5)

col = int(input("输入列数: "))
row = int(input("输入行数: "))
times = int(input("输入次数: "))

# 手动获取基准坐标（首次运行时使用）
print("\n请准备获取坐标，3秒后将显示鼠标位置（按Ctrl+C退出）")
time.sleep(3)
print("当前鼠标位置（请将鼠标移到第1行第1列学生位置）：")
try:
    for _ in range(5):
        x, y = pyautogui.position()
        print(f"X: {x}, Y: {y}", end='\r')
        time.sleep(1)
    base_x, base_y = pyautogui.position()
    print(f"\n已记录基准坐标: X={base_x}, Y={base_y}")

    print("\n请将鼠标移到加分按钮位置")
    for _ in range(5):
        x, y = pyautogui.position()
        print(f"加分按钮坐标: X={x}, Y={y}", end='\r')
        time.sleep(1)
    add_score_x, add_score_y = pyautogui.position()
    print(f"\n已记录加分按钮坐标: X={add_score_x}, Y={add_score_y}")

    # 输入行列间距（可根据实际布局调整）
    col_spacing = 50
    row_spacing = 20

except KeyboardInterrupt:
    print("\n用户取消坐标获取")
    os.system("pause")
    exit()

print("\n3秒后开始操作，请确保班级优化大师窗口已打开并处于前台...")
time.sleep(3)

for i in range(times):
    try:
        # 计算目标学生坐标（基于基准坐标和行列间距）
        student_x = base_x + (col - 1) * col_spacing  # 列偏移
        student_y = base_y + (row - 1) * row_spacing  # 行偏移

        # 移动到学生位置并点击
        pyautogui.moveTo(student_x, student_y, duration=0.5)  # 缓慢移动更精准
        pyautogui.click()

        # 点击加分按钮
        pyautogui.moveTo(add_score_x, add_score_y, duration=0.5)
        pyautogui.click()

        print(f"第{i + 1}次加分成功")
        time.sleep(1)

    except Exception as e:
        print(f"操作出错：{e}")

print("加分已完毕，请退出")
os.system("pause")

