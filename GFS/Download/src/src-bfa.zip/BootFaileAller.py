import pygame
import sys
import time
import os
import tkinter as tk
from tkinter import ttk, messagebox
import threading

# -------------------------- 全局配置 & 状态变量 --------------------------
# 窗口基础配置
WIDTH = 1024
HEIGHT = 768
TITLE = '系统启动错误模拟'
# 全局状态变量
current_error = ()

current_desc = ""
blink_state = True
blink_interval = 0.125
phase = 0
fullscreen_setup = False
pgame_running = False  # 标记Pygame模拟是否运行
screen = None  # Pygame屏幕对象
clock = None   # Pygame时钟对象

bios_draw_index = 0   # BIOS文本绘制索引
bios_draw_timer = 0   # BIOS逐行延时定时器
blink_timer = 0       # 闪烁效果定时器
clock = pygame.time.Clock()  # Pygame时钟（必须）

# -------------------------- 完整错误列表（原封不动） --------------------------
error_list = [
    # 1-10：CPU相关错误
    (
        ('CPU Fan Error', 'Press F1 to Continue, F2 to Enter Setup'),
        '中文简介：CPU风扇未检测到或转速异常，可能是风扇未连接、损坏或BIOS风扇阈值设置过高。'
    ),
    (
        ('CPU Over Temperature Error', 'System will shut down in 15 seconds'),
        '中文简介：CPU温度超过安全阈值，可能因散热不良、硅脂干涸或风扇故障导致，系统将自动关机保护硬件。'
    ),
    (
        ('CPU Voltage Error', 'Please check CPU power settings'),
        '中文简介：CPU供电电压异常，可能是主板供电模块故障、BIOS超频设置错误或电源输出不稳定。'
    ),
    (
        ('CPU Not Detected', 'Please ensure CPU is properly installed'),
        '中文简介：未检测到CPU，可能是CPU未正确安装、针脚损坏或主板CPU插槽故障。'
    ),
    (
        ('Unsupported CPU', 'BIOS update required for this processor'),
        '中文简介：CPU型号不被当前BIOS版本支持，需更新主板BIOS以兼容该处理器。'
    ),
    (
        ('CPU Core Ratio Error', 'Resetting to default settings'),
        '中文简介：CPU核心倍频设置错误，BIOS已自动恢复默认配置，可能因超频参数不合理导致。'
    ),
    (
        ('CPU Cache Error', 'System Halted'),
        '中文简介：CPU缓存测试失败，属于硬件故障，可能是CPU损坏或主板北桥芯片问题。'
    ),
    (
        ('CPU Thermal Throttling Activated',),
        '中文简介：CPU已触发热节流保护，为防止过热自动降低频率，建议改善散热条件。'
    ),
    (
        ('CPU Virtualization Technology Disabled', 'Enable in BIOS Setup'),
        '中文简介：CPU虚拟化技术未启用，若需运行虚拟机，需进入BIOS设置开启VT-x/AMD-V功能。'
    ),
    (
        ('CPU Fan Speed Zero Detected', 'Ignore and Continue? [Y/N]'),
        '中文简介：检测到CPU风扇转速为零，可能是风扇线接错接口（应接CPU_FAN而非SYS_FAN）或风扇损坏。'
    ),

    # 11-20：内存相关错误
    (
        ('Memory Error', 'Address: 0x000A7F2C, Data: 0x12345678'),
        '中文简介：内存读写错误，显示错误地址和数据，可能是内存条接触不良、不兼容或损坏。'
    ),
    (
        ('No Memory Detected', 'Please install memory modules in the DIMM slots'),
        '中文简介：未检测到内存，需检查内存条是否正确安装在DIMM插槽中，或尝试更换插槽。'
    ),
    (
        ('Memory Size Mismatch', 'Detected: 8GB, Expected: 16GB'),
        '中文简介：内存容量不匹配，BIOS检测到8GB内存但预期16GB，可能是其中一根内存条未被识别。'
    ),
    (
        ('Memory Frequency Mismatch', 'Running at 2133MHz instead of 3200MHz'),
        '中文简介：内存频率不匹配，当前运行在2133MHz（默认）而非标称的3200MHz，需在BIOS中开启XMP。'
    ),
    (
        ('Memory Channel Error', 'Dual Channel Mode Disabled'),
        '中文简介：内存通道错误，双通道模式已禁用，可能因内存条型号不统一或未按正确插槽安装（如A1+B1）。'
    ),
    (
        ('ECC Memory Error Detected', 'Corrected: 12 errors'),
        '中文简介：ECC内存检测到可纠正错误（已修复12处），通常是内存颗粒轻微不稳定，若频繁出现需更换内存。'
    ),
    (
        ('Memory Overclocking Failed', 'Resetting to default'),
        '中文简介：内存超频失败，BIOS已恢复默认设置，可能因超频参数过高或内存体质不足。'
    ),
    (
        ('Memory Slot Error', 'DIMM Slot 2 Not Responding'),
        '中文简介：内存插槽2无响应，可能是该插槽故障，建议将内存条插入其他插槽。'
    ),
    (
        ('Secure Boot Violation: Invalid Memory Configuration',),
        '中文简介：安全启动冲突：无效的内存配置，可能因开启Secure Boot时使用了不兼容的内存超频设置。'
    ),
    (
        ('Memory Test Failed (Stage 3)', 'Error Code: MEM-0003'),
        '中文简介：内存测试第3阶段失败（错误码MEM-0003），属于硬件级故障，需更换内存条。'
    ),

    # 21-30：存储设备错误
    (
        ('Hard Disk Not Detected', 'Check IDE/SATA cables and drives'),
        '中文简介：未检测到硬盘，检查IDE/SATA数据线、电源线是否连接，或硬盘是否故障。'
    ),
    (
        ('SSD Temperature Too High', 'Please check cooling'),
        '中文简介：固态硬盘温度过高，可能因散热不良导致，长期高温会影响SSD寿命。'
    ),
    (
        ('SATA Port 0 Error', 'No Device Connected'),
        '中文简介：SATA接口0错误，该接口未连接设备，若需使用此接口，检查设备是否连接正确。'
    ),
    (
        ('M.2 NVMe Drive Not Detected', 'Check if drive is properly seated'),
        '中文简介：未检测到M.2 NVMe硬盘，检查硬盘是否完全插入M.2插槽，螺丝是否固定。'
    ),
    (
        ('Disk SMART Status Bad', 'Backup Data Immediately'),
        '中文简介：硬盘SMART状态异常，预示硬盘即将损坏，需立即备份数据并更换硬盘。'
    ),
    (
        ('USB Drive Malfunction', 'Disconnect and Reconnect'),
        '中文简介：USB存储设备故障，建议拔插设备或更换USB接口，可能是设备损坏或接口供电不足。'
    ),
    (
        ('Optical Drive Not Found', 'Check Power and Data Cables'),
        '中文简介：未找到光驱，检查光驱的电源线和数据线是否连接，或光驱本身故障。'
    ),
    (
        ('RAID Array Degraded', 'One Drive Failed in RAID 1'),
        '中文简介：RAID阵列降级，RAID 1中有一块硬盘故障，需更换故障盘并重建阵列。'
    ),
    (
        ('Invalid Boot Disk', 'The selected disk is not bootable'),
        '中文简介：无效的启动盘，选中的磁盘未安装操作系统或引导扇区损坏，无法启动。'
    ),
    (
        ('External Drive Boot Disabled', 'Enable in BIOS Boot Menu'),
        '中文简介：外部设备启动已禁用，若需从U盘/移动硬盘启动，需进入BIOS启动菜单开启。'
    ),

    # 31-40：主板与接口错误
    (
        ('CMOS Battery Low', 'Please Replace Battery'),
        '中文简介：CMOS电池电量低，导致BIOS设置无法保存，需更换主板上的纽扣电池（CR2032）。'
    ),
    (
        ('CMOS Checksum Error', 'Loading Default Settings'),
        '中文简介：CMOS校验和错误，BIOS设置可能被篡改或电池没电，已加载默认配置。'
    ),
    (
        ('BIOS Corrupted', 'Attempting to Recover from Backup'),
        '中文简介：BIOS固件损坏，正在尝试从备份恢复，若失败需通过U盘刷新BIOS。'
    ),
    (
        ('PCIe Device Error', 'Slot 1: Unknown Device'),
        '中文简介：PCIe设备错误，插槽1中的设备无法识别，可能是显卡/网卡未插牢或与主板不兼容。'
    ),
    (
        ('USB Controller Error', 'USB Ports Disabled'),
        '中文简介：USB控制器错误，所有USB端口已禁用，可能是主板USB芯片故障或驱动损坏。'
    ),
    (
        ('Integrated Graphics Disabled', 'No PCIe Graphics Card Detected'),
        '中文简介：集成显卡已禁用，但未检测到独立显卡，需启用集成显卡或安装独立显卡。'
    ),
    (
        ('Network Interface Card (NIC) Not Found',),
        '中文简介：未找到网卡，可能是集成网卡被禁用（需在BIOS开启）或独立网卡硬件故障。'
    ),
    (
        ('Audio Controller Error', 'HD Audio Not Detected'),
        '中文简介：音频控制器错误，未检测到高清音频设备，可能是驱动问题或声卡硬件故障。'
    ),
    (
        ('Front Panel USB Not Connected', 'Check F_PANEL Headers'),
        '中文简介：前置USB未连接，检查机箱前置USB线是否正确插在主板F_PANEL接口上。'
    ),
    (
        ('TPM Module Not Detected', 'Required for BitLocker'),
        '中文简介：未检测到TPM模块，该模块是BitLocker加密的必要组件，需在BIOS中启用或安装硬件TPM。'
    ),

    # 41-50：启动与配置错误
    (
        ('Boot Order Not Set', 'Please Configure in BIOS Setup'),
        '中文简介：未设置启动顺序，需进入BIOS设置从硬盘/U盘等设备的启动优先级。'
    ),
    (
        ('Secure Boot Violation', 'Unauthorized Firmware Loaded'),
        '中文简介：安全启动冲突，检测到未授权的固件，需禁用Secure Boot或使用签名的启动文件。'
    ),
    (
        ('UEFI BIOS Mode Not Supported', 'Switch to Legacy Mode'),
        '中文简介：不支持UEFI BIOS模式，需在BIOS中切换到传统（Legacy）启动模式。'
    ),
    (
        ('BIOS Update Failed', 'System May Be Unstable'),
        '中文简介：BIOS更新失败，系统可能不稳定，建议重新尝试更新或恢复出厂BIOS。'
    ),
    (
        ('Password Check Failed', 'System Locked'),
        '中文简介：密码验证失败，系统已锁定，需输入正确的BIOS开机密码或清除CMOS密码。'
    ),
    (
        ('Invalid BIOS Settings', 'Reset to Optimized Defaults? [Y/N]'),
        '中文简介：无效的BIOS设置，是否恢复为优化默认值？通常因设置冲突导致系统无法启动。'
    ),
    (
        ('Fast Boot Not Working', 'Legacy USB Devices Detected'),
        '中文简介：快速启动功能失效，因检测到传统USB设备，需移除USB设备或禁用Fast Boot。'
    ),
    (
        ('Virtualization Technology Not Supported', 'CPU Does Not Support VT-x'),
        '中文简介：不支持虚拟化技术，该CPU不具备VT-x/AMD-V功能，无法运行依赖虚拟化的软件。'
    ),
    (
        ('System Time Not Set', 'Please Set Date and Time in BIOS'),
        '中文简介：系统时间未设置，需进入BIOS设置正确的日期和时间，可能因CMOS电池没电导致。'
    ),
    (
        ('Chassis Intrusion Detected', 'System Was Opened'),
        '中文简介：检测到机箱被打开，可能是有人拆卸过电脑机箱，需在BIOS中清除该警报（Chassis Intrusion）。'
    ),
    # 51-60：系统启动核心错误
    (
        ('BOOTMGR is missing', 'Press Ctrl+Alt+Del to restart'),
        '中文简介：系统启动管理器文件丢失，常见于Windows Vista及以上系统，需通过安装盘修复引导。'
    ),
    (
        ('NTLDR is missing', 'Press Ctrl+Alt+Del to restart'),
        '中文简介：NT加载程序丢失，多见于Windows XP系统，可能因病毒破坏或误删系统文件导致。'
    ),
    (
        ('A disk read error occurred', 'Press Ctrl+Alt+Del to restart'),
        '中文简介：磁盘读取错误，可能是硬盘坏道、数据线松动或分区表损坏，需检查硬件连接。'
    ),
    (
        ('Invalid partition table', 'Press Ctrl+Alt+Del to restart'),
        '中文简介：分区表无效，因分区操作失误或病毒攻击导致，需修复分区表或重新分区。'
    ),
    (
        ('Error loading operating system', 'Press Ctrl+Alt+Del to restart'),
        '中文简介：加载操作系统时出错，可能是主引导扇区损坏或硬盘不被BIOS支持。'
    ),
    (
        ("An operating system wasn't found.Try disconnecting any drives that don't",  "contain an operating system", 'Press Ctrl+Alt+Del to restart'),
        '中文简介：未找到操作系统，可能是硬盘未安装系统、连接了不含系统的外接存储设备，或BIOS未识别到硬盘。'
    ),
    (
        ('Boot Configuration Data is missing', 'Press Ctrl+Alt+Del to restart'),
        '中文简介：启动配置数据（BCD）丢失，系统无法识别启动设置，需重建BCD。'
    ),
    (
        ('WINLOAD.EXE is corrupt', 'Press Ctrl+Alt+Del to restart'),
        '中文简介：Windows加载程序损坏，无法加载系统内核，需通过安装盘修复。'
    ),
    (
        ('Master Boot Record is corrupt', 'Press Ctrl+Alt+Del to restart'),
        '中文简介：主引导记录（MBR）损坏，硬盘无法引导系统，可执行bootrec /fixmbr修复。'
    ),
    (
        ('Disk boot failure', 'Insert system disk and press Ctrl+Alt+Del'),
        '中文简介：磁盘启动失败，插入系统盘后按Ctrl+Alt+Del重启，可能是启动顺序错误。'
    ),
    (
        ('Remove disks or other media', 'Press any key to restart'),
        '中文简介：磁盘启动失败，插入系统盘后按Ctrl+Alt+Del重启，可能是启动顺序错误。'
    ),
    (
        ('BOOTMGR is compressed', 'Press Ctrl+Alt+Del to restart'),
        '中文简介：启动管理器压缩，插入系统盘后按Ctrl+Alt+Del重启，需将BOOTMGR解压缩。'
    ),
    (
        ('NTLDR is compressed', 'Press Ctrl+Alt+Del to restart'),
        '中文简介：启动管理器压缩，插入系统盘后按Ctrl+Alt+Del重启，需将NTLDR解压缩。'
    )
]

BIOS_BOOT_TEXT = [
    "American Megatrends Inc.",
    "BIOS Version 5.12 (2025/01/15)",
    "CPU: Intel i7-12700K @ 3.60GHz",
    "Memory: 16GB DDR4-3200 Dual Channel",
    "Storage: NVMe SSD 1TB + SATA HDD 2TB",
    "GPU: NVIDIA RTX 4070 Ti",
    "Checking System Health... OK",
    "Boot Priority: NVMe SSD",
    "Press DEL for SETUP | F11 for Boot Menu",
    "Starting system boot...",
    ""
]



# -------------------------- 核心模拟函数（原生Pygame实现） --------------------------
def scan_error():
    """生成错误列表数据（适配Treeview）"""
    error_data = []
    for i in range(len(error_list)):
        error_id = i + 1  # 错误编号（1-61）
        error_name = error_list[i][0][0] if len(error_list[i][0]) > 0 else "无错误标题"  # 错误类型
        # 拼接执行操作（多个文本合并）
        operate_text = " | ".join(error_list[i][0][1:]) if len(error_list[i][0]) > 1 else "无执行操作"
        # 提取中文解释（去掉前缀）
        chinese_desc = error_list[i][1].replace("中文简介：", "") if error_list[i][1] else "无中文解释"
        error_data.append((error_id, error_name, operate_text, chinese_desc))
    return error_data

def setup_fullscreen():
    """全屏设置"""
    global screen
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN | pygame.HWSURFACE | pygame.DOUBLEBUF)

def toggle_blink():
    """闪烁状态切换"""
    global blink_state
    blink_state = not blink_state

def switch_phase():
    """4秒后切换到显示错误阶段"""
    global phase
    phase = 1

def draw_error():
    """绘制错误界面"""
    global fullscreen_setup, screen
    # 初始化全屏
    if not fullscreen_setup:
        setup_fullscreen()
        fullscreen_setup = True
    
    # 填充黑色背景
    screen.fill((0, 0, 0))

def draw_error():
    global screen, blink_state, fullscreen_setup, bios_draw_timer, blink_timer
    
    # 初始化全屏（保留原有设置）
    if not fullscreen_setup:
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN | pygame.HWSURFACE | pygame.DOUBLEBUF)
        fullscreen_setup = True
        # 初始化延时定时器（仅首次全屏时）
        global bios_draw_index
        bios_draw_index = 0  # 当前绘制到第几行BIOS文本
        bios_draw_timer = 0   # BIOS逐行绘制定时器
        blink_timer = 0      # 闪烁白点定时器

    # 填充黑色背景
    screen.fill((0, 0, 0))

    if phase == 0:
        # 前4秒：闪烁白点（Pygame定时器控制闪烁间隔）
        blink_timer += clock.tick(60) / 1000  # 累计毫秒数转秒
        if blink_timer >= 0.5:  # 0.5秒闪烁一次
            blink_state = not blink_state
            blink_timer = 0
        if blink_state:
            pygame.draw.rect(screen, (255, 255, 255), (20, 20, 15, 4))
    else:
        # 显示英文错误信息（修复字体路径错误）
        cwd = None
        try:
            # 优先用系统字体，避免自定义字体路径问题
            font_en = pygame.font.SysFont("Flexi_IBM_VGA_False_437", 32)
        except:
            font_en = pygame.font.SysFont("font", 32)

        # Pygame定时器实现BIOS文本逐行延时输出（0.2秒/行）
        bios_draw_timer += clock.tick(60) / 1000
        if bios_draw_timer >= 0.2 and bios_draw_index < len(BIOS_BOOT_TEXT):
            bios_draw_index += 1
            bios_draw_timer = 0
        
        # 绘制已加载的BIOS文本（逐行显示）
        for i in range(bios_draw_index):
            text_surface = font_en.render(BIOS_BOOT_TEXT[i], True, (255, 255, 255))
            screen.blit(text_surface, (20, 50 + i * 30))
        
        # 绘制错误信息（BIOS文本加载完成后才显示）
        if bios_draw_index >= len(BIOS_BOOT_TEXT):
            error_start_y = 50 + len(BIOS_BOOT_TEXT) * 30 + 50
            for i, text in enumerate(current_error):
                text_surface = font_en.render(text, True, (255, 255, 255))
                screen.blit(text_surface, (20, error_start_y + i * 30))
            
            # 错误下方闪烁白点（Pygame定时器控制）
            blink_timer += clock.tick(60) / 1000
            if blink_timer >= 0.5:
                blink_state = not blink_state
                blink_timer = 0
            blink_y = error_start_y + len(current_error) * 30 + 30
            if blink_state:
                pygame.draw.rect(screen, (255, 255, 255), (20, blink_y, 15, 4))
    
    # 更新屏幕
    pygame.display.flip()

def run_pygame_simulation(index, timeout):
    """原生Pygame模拟主循环"""
    global current_error, current_desc, phase, blink_state, fullscreen_setup, screen, clock, pgame_running
    
    # 初始化Pygame
    pygame.init()
    pygame.display.set_caption(TITLE)
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    
    # 重置状态
    phase = 0
    blink_state = True
    fullscreen_setup = False
    pgame_running = True
    
    # 获取错误数据
    current_error, current_desc = error_list[index - 1]
    
    # 延时
    if timeout > 0:
        time.sleep(timeout)
    
    # 定时器（用pygame时间戳实现）
    blink_timer = 0
    phase_timer = 0
    
    # Pygame主循环
    while pgame_running:
        # 事件处理
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pgame_running = False
            # ESC退出全屏
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    screen = pygame.display.set_mode((WIDTH, HEIGHT))
                    fullscreen_setup = False
        
        # 控制闪烁（每blink_interval秒切换一次）
        blink_timer += clock.tick(60) / 1000
        if blink_timer >= blink_interval:
            toggle_blink()
            blink_timer = 0
        
        # 4秒后切换阶段
        phase_timer += clock.tick(60) / 1000
        if phase_timer >= num_var.get():
            switch_phase()
            phase_timer = 0
        
        # 绘制界面
        draw_error()
    
    # 退出Pygame
    pygame.quit()

# -------------------------- 后台执行模拟 --------------------------
def run_simulation(index, timeout):
    """后台线程执行模拟"""
    try:
        run_pygame_simulation(index, timeout)
    except Exception as e:
        messagebox.showerror("模拟失败", f"执行错误：{str(e)}")

# -------------------------- Tkinter GUI主窗口（必显示） --------------------------
if __name__ == "__main__":
    # 强制设置PYGAME窗口显示（解决隐藏问题）
    os.environ['SDL_VIDEO_WINDOW_POS'] = "100,100"
    """纯TTK GUI主函数"""

    
    

    # 1. 创建主窗口（强制置顶，确保显示）
    root = tk.Tk()
    root.title("系统启动错误模拟程序")
    root.geometry("1200x700")  # 加宽窗口适配表格
    root.resizable(True, True)
    root.attributes('-topmost', True)  # 窗口置顶
    root.update()  # 强制刷新窗口
    root.attributes('-topmost', False) # 取消置顶（避免遮挡其他操作）
    
    # 中文显示修复
    root.option_add("*Font", "微软雅黑 10")
    style = ttk.Style(root)
    style.theme_use("clam")

    num_var = tk.IntVar(value=1)

    # 2. 主容器
    main_frame = ttk.Frame(root, padding="20 20 20 20")
    main_frame.pack(fill=tk.BOTH, expand=True)

    # 3. 标题
    title_label = ttk.Label(main_frame, text="系统启动错误模拟程序", font=("微软雅黑", 18, "bold"))
    title_label.pack(pady=(0, 20), anchor=tk.CENTER)

    # 4. 错误列表显示区（Treeview表格）
    list_label = ttk.Label(main_frame, text="错误列表（共61条）：", font=("微软雅黑", 12))
    list_label.pack(anchor=tk.W)
    
    # 滚动条+Treeview表格
    list_frame = ttk.Frame(main_frame)
    list_frame.pack(fill=tk.BOTH, expand=True, pady=(5, 15))
    
    # 垂直滚动条
    scroll_y = ttk.Scrollbar(list_frame, orient=tk.VERTICAL)
    scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
    # 水平滚动条
    scroll_x = ttk.Scrollbar(list_frame, orient=tk.HORIZONTAL)
    scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
    
    # 创建Treeview表格
    error_tree = ttk.Treeview(
        list_frame,
        yscrollcommand=scroll_y.set,
        xscrollcommand=scroll_x.set,
        columns=("id", "error_name","Will_execute_operating","chinese_debug"),  # 列名
        show="headings",  # 只显示列标题
        height=20  # 显示行数
    )
    error_tree.pack(fill=tk.BOTH, expand=True)
    
    # 配置滚动条
    scroll_y.config(command=error_tree.yview)
    scroll_x.config(command=error_tree.xview)
    
    # 设置列标题和宽度
    error_tree.heading("id", text="错误编号")
    error_tree.heading("error_name", text="错误类型")
    error_tree.heading("Will_execute_operating", text="执行操作")
    error_tree.heading("chinese_debug", text="中文解释")
    
    # 设置列宽
    error_tree.column("id", width=80, anchor=tk.CENTER)
    error_tree.column("error_name", width=250, anchor=tk.W)
    error_tree.column("Will_execute_operating", width=350, anchor=tk.W)
    error_tree.column("chinese_debug", width=400, anchor=tk.W)
    
    # 填充错误列表
    def load_error_data():
        """加载错误数据到表格"""
        # 清空现有数据
        for item in error_tree.get_children():
            error_tree.delete(item)
        # 加载新数据
        show_errors = scan_error()
        for row in show_errors:
            error_tree.insert("", tk.END, values=row)
    
    # 初始加载数据
    load_error_data()

    # 5. 输入区
    input_frame = ttk.Frame(main_frame)
    input_frame.pack(fill=tk.X, pady=(0, 20))
    
    # 错误编号
    ttk.Label(input_frame, text="错误编号（1-61）：", font=("微软雅黑", 10)).grid(row=0, column=0, padx=(0, 5), sticky=tk.W)
    index_var = tk.StringVar()
    index_entry = ttk.Entry(input_frame, textvariable=index_var, width=15, font=("微软雅黑", 10))
    index_entry.grid(row=0, column=1, padx=(0, 20), sticky=tk.W)
    
    # 模拟延时
    ttk.Label(input_frame, text="模拟延时(秒)：", font=("微软雅黑", 10)).grid(row=0, column=2, padx=(0, 5), sticky=tk.W)
    timeout_var = tk.StringVar(value="0")
    timeout_entry = ttk.Entry(input_frame, textvariable=timeout_var, width=15, font=("微软雅黑", 10))
    timeout_entry.grid(row=0, column=3, padx=(0, 30), sticky=tk.W)

    
    time_show_spin = ttk.Spinbox(input_frame, from_=0.1, to=10, textvariable=
                                 num_var, width=10,increment=0.1)
    
    state_var = tk.BooleanVar(value=False)
    
    
    ttk.Label(input_frame, text="光标停留时长(秒)：", font=("微软雅黑", 10)).grid(row=1, column=0, padx=(0, 5), sticky=tk.W)
    
    radio_var = tk.IntVar()

    a = ttk.Radiobutton(input_frame,text="简单化",variable=radio_var,value=0)
    b = ttk.Radiobutton(input_frame,text="属性化",variable=radio_var,value=1)
    c = ttk.Radiobutton(input_frame,text="表格化",variable=radio_var,value=2)
    d = ttk.Radiobutton(input_frame,text="无",variable=radio_var,value=3)

    a.grid(row=1, column=2, padx=(0, 30), sticky=tk.W)
    b.grid(row=1, column=3, padx=(0, 30), sticky=tk.W)
    c.grid(row=1, column=4, padx=(0, 30), sticky=tk.W)
    d.grid(row=1, column=5, padx=(0, 30), sticky=tk.W)

    time_show_spin.grid(row=1, column=1, padx=(0, 30), sticky=tk.W)
    

    # 6. 功能按钮
    def refresh_error_list():
        """刷新错误列表"""
        load_error_data()
        messagebox.showinfo("刷新成功", "错误列表已重新加载！")
    
    def execute_sim():
        """执行模拟"""
        if pgame_running:
            messagebox.showwarning("提示", "已有模拟在运行，请先关闭当前模拟窗口！")
            return
        
        # 输入校验
        try:
            index = int(index_var.get().strip())
            timeout = int(timeout_var.get().strip())
            if not (1 <= index <= len(error_list)):
                messagebox.showerror("输入错误", f"编号需在1-{len(error_list)}之间！")
                return
            if timeout < 0:
                messagebox.showerror("输入错误", "延时不能为负数！")
                return
        except ValueError:
            messagebox.showerror("输入错误", "编号和延时必须为纯数字！")
            return
        
        # 启动后台线程
        sim_thread = threading.Thread(target=run_simulation, args=(index, timeout), daemon=True)
        sim_thread.start()
        
        # 提示
        error_title = error_list[index-1][0][0]
        messagebox.showinfo("模拟启动", f"已启动错误{index}模拟！\n标题：{error_title}\n提示：按ESC退出全屏，关闭模拟窗口返回")

    # 按钮布局
    btn_frame = ttk.Frame(input_frame)
    btn_frame.grid(row=0, column=4, sticky=tk.W)
    ttk.Button(btn_frame, text="刷新错误列表", command=refresh_error_list, width=12).pack(side=tk.LEFT, padx=(0, 10))
    ttk.Button(btn_frame, text="执行错误模拟", command=execute_sim, width=12).pack(side=tk.LEFT)

    # 强制刷新窗口（解决部分系统不显示问题）
    root.update_idletasks()
    # 运行主循环
    root.mainloop()

# -------------------------- 程序入口 --------------------------

 