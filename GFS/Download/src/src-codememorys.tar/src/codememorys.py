import sys
import os
import re
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5 import uic
from PyQt5.QtGui import QTextCharFormat, QColor, QFont, QSyntaxHighlighter, QTextCursor
from PyQt5.QtCore import QRegExp
from tkinter import filedialog
from tkinter import messagebox as msgbox
import subprocess
import builtins
import inspect

def get_all_builtin_functions():
    builtin_funcs = []
    for name in dir(builtins):
        obj = getattr(builtins, name)
        if inspect.isfunction(obj) or inspect.isbuiltin(obj):
            builtin_funcs.append(name)
    return sorted(builtin_funcs)

def get_bath_content(of):
    batch_content = f'''
    @echo off
    {of} 
    
    echo.
    echo. 
    pause                   
    exit
    '''
    return batch_content

# 获取路径的辅助函数
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)

def get_cmd_output(command):
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout + result.stderr,result.returncode

def _get_cmd_output(command):
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout,result.stderr,result.returncode

def get_file_type(path):
    suffix = os.path.splitext(path)[1].lower()
    type_map = {
        '.c': 'c', '.cpp': 'cpp', '.h': 'h', '.hpp': 'hpp',
        '.py': 'python', '.pyw': 'python', '.pyi': 'python',
        '.html': 'html', '.htm': 'html', '.css': 'css', '.js': 'js',
        '.java': 'java',
        '.bat': 'batch', '.cmd': 'batch',
        '.vbs': 'vbs', '.sh': 'shell'
    }
    return type_map.get(suffix, 'unknown')

# ==========================================
# 🎨 修复后：独立分语言语法高亮器
# ==========================================
class CodeHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.cur_lang = "unknown"
        self.setup_formats()

    def set_lang(self, lang):
        self.cur_lang = lang
        self.rehighlight()

    def setup_formats(self):
        # 通用
        self.keyword_format = QTextCharFormat()
        self.keyword_format.setForeground(QColor(120,194,173)) 

        self.type_format = QTextCharFormat()
        self.type_format.setForeground(QColor(243,150,154)) 
        self.type_format.setFontWeight(QFont.Bold)

        self.preprocessor_format = QTextCharFormat()
        self.preprocessor_format.setForeground(QColor(108,195,213))
        self.preprocessor_format.setFontWeight(QFont.Bold)

        self.number_format = QTextCharFormat()
        self.number_format.setForeground(QColor(255,206,103))

        self.string_format = QTextCharFormat()
        self.string_format.setForeground(QColor(255,120,81))

        self.comment_format = QTextCharFormat()
        self.comment_format.setForeground(QColor(86,204,157))
        
        self.ukeyword_format = QTextCharFormat()
        self.ukeyword_format.setForeground(QColor(139,194,136))

    def get_rules(self):
        rules = []
        lang = self.cur_lang

        # ========== C/C++ ==========
        if lang in ("c","cpp","h","hpp"):
            rules.append((QRegExp(r'^\s*#\w+'), self.preprocessor_format))
            types = [
                'class', 'struct', 'enum', 'union', 'namespace', 'template',
                'int', 'float', 'double', 'char', 'void', 'bool', 'long', 'short',
                'unsigned', 'signed', 'const', 'static', 'volatile', 'extern',
                'public', 'private', 'protected', 'virtual', 'override', 'final'
            ]
            for w in types:
                rules.append((QRegExp(r'\b'+w+r'\b'), self.type_format))

            keywords = [
                'if', 'else', 'for', 'while', 'do', 'switch', 'case', 'default',
                'break', 'continue', 'return', 'goto', 'sizeof', 'typedef',
                'new', 'delete', 'try', 'catch', 'throw', 'using', 'typename',
                'true', 'false', 'nullptr'
            ]
            for w in keywords:
                rules.append((QRegExp(r'\b'+w+r'\b'), self.keyword_format))

            user_keywords = [
                "cin", "cout", "endl", "string", "vector", "map", "set", 
                "list", "deque", "stack", "queue", "pair", "sort", "swap",
                "shared_ptr", "unique_ptr", "ifstream", "ofstream", "std"
            ]
            for w in user_keywords:
                rules.append((QRegExp(r'\b'+w+r'\b'), self.ukeyword_format))

            rules.append((QRegExp(r'\b[0-9]+\.?[0-9]*\b'), self.number_format))
            rules.append((QRegExp(r'\b0x[0-9A-Fa-f]+\b'), self.number_format))
            rules.append((QRegExp(r'"[^"\\]*(\\.[^"\\]*)*"'), self.string_format))
            rules.append((QRegExp(r'//[^\n]*'), self.comment_format))

        # ========== Python ==========
        elif lang == "python":
            py_words = [
                'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue',
                'def', 'del', 'elif', 'else', 'except', 'False', 'finally', 'for',
                'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'None',
                'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'True', 'try',
                'while', 'with', 'yield', 'self', 'cls'
            ]
            
            py_bf = [
                'abs', 'all', 'any', 'ascii', 'bin', 'bool', 'breakpoint', 'bytearray', 'bytes',
                'callable', 'chr', 'classmethod', 'compile', 'complex', 'delattr', 'dict',
                'dir', 'divmod', 'enumerate', 'eval', 'exec', 'filter', 'float', 'format',
                'frozenset', 'getattr', 'globals', 'hasattr', 'hash', 'help', 'hex', 'id',
                'input', 'int', 'isinstance', 'issubclass', 'iter', 'len', 'list', 'map',
                'max', 'memoryview', 'min', 'next', 'object', 'oct', 'open', 'ord', 'pow',
                'print', 'property', 'range', 'repr', 'reversed', 'round', 'set', 'slice',
                'sorted', 'staticmethod', 'str', 'sum', 'super', 'tuple', 'type', 'vars',
                'zip', '__import__'
            ]
            
            for w in py_words:
                rules.append((QRegExp(r'\b'+w+r'\b'), self.keyword_format))
                
            for w in py_bf:
                rules.append((QRegExp(r'\b'+w+r'\b'), self.ukeyword_format))
                    
            rules.append((QRegExp(r'#.*'), self.comment_format))
            rules.append((QRegExp(r"'''[^']*'''"), self.string_format))
            rules.append((QRegExp(r'"""[^"]*"""'), self.string_format))
            rules.append((QRegExp(r"'[^']*'"), self.string_format))
            rules.append((QRegExp(r'"[^"]*"'), self.string_format))
            rules.append((QRegExp(r'\b[0-9]+\b'), self.number_format))

        # ========== Java ==========
        elif lang == "java":
            java_words = [
                'abstract', 'assert', 'boolean', 'break', 'byte', 'case', 'catch',
                'char', 'class', 'const', 'continue', 'default', 'do', 'double',
                'else', 'enum', 'extends', 'final', 'finally', 'float', 'for',
                'if', 'implements', 'import', 'instanceof', 'int', 'interface',
                'long', 'native', 'new', 'null', 'package', 'private', 'protected',
                'public', 'return', 'short', 'static', 'strictfp', 'super',
                'switch', 'synchronized', 'this', 'throw', 'throws', 'transient',
                'try', 'void', 'volatile', 'while'
            ]
            for w in java_words:
                rules.append((QRegExp(r'\b'+w+r'\b'), self.type_format))
            rules.append((QRegExp(r'"[^"]*"'), self.string_format))
            rules.append((QRegExp(r'//[^\n]*'), self.comment_format))

        # ========== JS ==========
        elif lang == "js":
            js_words = [
                'await', 'break', 'case', 'catch', 'class', 'const', 'continue',
                'debugger', 'default', 'delete', 'do', 'else', 'export', 'extends',
                'false', 'finally', 'for', 'function', 'if', 'import', 'in',
                'instanceof', 'let', 'new', 'null', 'return', 'super', 'switch',
                'this', 'throw', 'true', 'try', 'typeof', 'var', 'void', 'while',
                'with', 'yield', 'document', 'window', 'console', 'alert'
            ]
            for w in js_words:
                rules.append((QRegExp(r'\b'+w+r'\b'), self.keyword_format))
            rules.append((QRegExp(r'"[^"]*"'), self.string_format))
            rules.append((QRegExp(r'//[^\n]*'), self.comment_format))

        # ========== HTML ==========
        elif lang == "html":
            html_all = [
                'a', 'abbr', 'address', 'area', 'article', 'aside', 'audio', 'b',
                'base', 'bdi', 'bdo', 'blockquote', 'body', 'br', 'button', 'canvas',
                'caption', 'cite', 'code', 'col', 'colgroup', 'data', 'datalist', 'dd',
                'del', 'details', 'dfn', 'div', 'dl', 'dt', 'em', 'embed', 'fieldset',
                'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3', 'h4',
                'h5', 'h6', 'head', 'header', 'hr', 'html', 'i', 'iframe', 'img',
                'input', 'ins', 'kbd', 'label', 'legend', 'li', 'link', 'main', 'map',
                'mark', 'meta', 'meter', 'nav', 'noscript', 'object', 'ol', 'optgroup',
                'option', 'output', 'p', 'param', 'picture', 'pre', 'progress', 'q',
                'rp', 'rt', 'ruby', 's', 'samp', 'script', 'section', 'select', 'small',
                'source', 'span', 'strong', 'style', 'sub', 'summary', 'sup', 'table',
                'tbody', 'td', 'template', 'textarea', 'tfoot', 'th', 'thead', 'time',
                'title', 'tr', 'track', 'u', 'ul', 'var', 'video', 'wbr'
            ]
            for tag in html_all:
                rules.append((QRegExp(r'<\s*/?\s*'+tag+r'\b'), self.type_format))
            rules.append((QRegExp(r'".*?"'), self.string_format))

        # ========== CSS ==========
        elif lang == "css":
            css_props = [
                'color', 'background', 'width', 'height', 'margin', 'padding',
                'border', 'font', 'display', 'position', 'top', 'left', 'right',
                'bottom', 'flex', 'grid', 'align', 'justify', 'text', 'line',
                'letter', 'opacity', 'overflow', 'float', 'clear', 'z-index',
                'box-shadow', 'transition', 'transform', 'animation'
            ]
            for p in css_props:
                rules.append((QRegExp(r'\b'+p+r'\s*:'), self.ukeyword_format))
            rules.append((QRegExp(r'/\*[\s\S]*?\*/'), self.comment_format))

        # ========== Batch ==========
        elif lang == "batch":
            batch = [
                'echo', 'set', 'if', 'else', 'pause', 'exit', 'cls', 'cd', 'dir',
                'del', 'copy', 'move', 'ren', 'rd', 'md', 'call', 'start', 'goto',
                'shift', 'path', 'title', 'mode', 'rem'
            ]
            for cmd in batch:
                rules.append((QRegExp(r'\b'+cmd+r'\b'), self.preprocessor_format))
            rules.append((QRegExp(r'^rem.*'), self.comment_format))

        return rules

    def highlightBlock(self, text):
        rules = self.get_rules()
        for pattern, fmt in rules:
            idx = pattern.indexIn(text)
            while idx >= 0:
                length = pattern.matchedLength()
                self.setFormat(idx, length, fmt)
                idx = pattern.indexIn(text, idx + length)

# ==========================================
# 🖥️ 主窗口类 完全不动你原有逻辑，只加一行设置语言
# ==========================================
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.issave = False
        self.fp = None
        self.lang = None
        self.rc = 0
        self.out = ""
               
        ui_path = resource_path("UserInterface\\Editor.ui")
        uic.loadUi(ui_path, self)
        
        try:
            self.actionOpen_File.triggered.connect(self.OpenFile)
            self.actionSave.triggered.connect(self.SaveFile)
            self.actionComplie.triggered.connect(self.Compile)
            self.actionRun.triggered.connect(self.execute)
            self.actionComplie_Run.triggered.connect(self.run)
            print("✅ 菜单绑定成功！")
        except AttributeError as e:
            print(f"❌ 绑定错误: {e}")

        self.highlighter = CodeHighlighter(self.textEdit.document())
        self.output_file = None

    def OpenFile(self):
        file_path = filedialog.askopenfilename(
            title="打开文件",
            filetypes=[("C++ Source", "*.c *.cpp"),
                       ("C++ Headers", "*.h *.hpp"),
                       ("Python Source","*.py *.pyw *.pyi"),
                       ("Html Source","*.html *.css"),
                       ("JavaScript Source","*.js"),
                       ("Java Source","*.java"),
                       ("VBS Script Source","*.vbs"),
                       ("MSBatch Source","*.bat"),
                       ("Shell Script Source","*.sh")
                       ]
        )
        
        if not file_path:
            return

        self.fp = file_path
        self.textEdit.clear()
        try:
            with open(self.fp, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                self.textEdit.insertPlainText(content)
                self.issave = True
        except Exception as e:
            msgbox.showinfo("Error", f"打开失败: {e}")
            
        self.lang = get_file_type(file_path)
        # 关键：打开文件立刻设置对应语言高亮
        self.highlighter.set_lang(self.lang)
        
        print(self.lang)
        self.tabWidget.setCurrentIndex(0) 
            
    def SaveFile(self):
        if not self.fp:
            self.SaveAsFile()
            return
        
        try:
            with open(self.fp, "w", encoding="utf-8", errors="ignore") as f:
                f.write(self.textEdit.toPlainText())
            self.issave = True
        except Exception as e:
            msgbox.showinfo("Error", f"保存失败: {e}")
        
        self.lang = get_file_type(self.fp)
        self.highlighter.set_lang(self.lang)

    def SaveAsFile(self):
        file_path = filedialog.asksaveasfilename(
            title="保存文件",
            defaultextension=".cpp",
            filetypes=[("C++ Source", "*.c *.cpp"),
                       ("C++ Headers", "*.h *.hpp"),
                       ("Python Source","*.py *.pyw *.pyi"),
                       ("Html Source","*.html *.css"),
                       ("JavaScript Source","*.js"),
                       ("Java Source","*.java"),
                       ("VBS Script Source","*.vbs"),
                       ("MSBatch Source","*.bat"),
                       ("Shell Script Source","*.sh")
                       ]
        )
        if file_path:
            self.fp = file_path
            self.SaveFile()
            self.lang = get_file_type(file_path)
            self.highlighter.set_lang(self.lang)
        
    def execute(self):
        if self.lang == "cpp" or self.lang == "c":
            self.Compile()
            self.run()
        elif self.lang == "python":
            self.run_py(self.fp)

    def Compile(self, compiler_path=None, arguments=None):
        self.SaveFile()
        self.textEdit_2.clear()
        self.tabWidget.setCurrentIndex(1)
        if not self.issave or not self.fp:
            self.SaveFile()
            if not self.fp:
                return

        if compiler_path is None:
            compiler_path = resource_path("MinGW\\bin\\g++.exe")
            if not os.path.exists(compiler_path):
                compiler_path = "g++.exe"
            
        compiler_path = resource_path("MinGW\\bin\\g++.exe")
        self.output_file = os.path.splitext(self.fp)[0] + ".exe"
        
        if arguments is None:
            argument_list = [
                f'"{self.fp}"',
                "-o",
                f'"{self.output_file}"'
            ]
            arguments = ' '.join(argument_list)
        
        full_command = f'"{compiler_path}" {arguments}'
        self.out,self.rc = get_cmd_output(full_command)
        self.textEdit_2.insertPlainText(self.out)
        
        if self.rc == 0:
            self.textEdit_2.insertPlainText("\nBuild Successful!\noutput:{}".format(os.path.splitext(self.fp)[0] + ".exe\n"))
        else:
            self.textEdit_2.insertPlainText("Build Failed! \nPlease Check Code、Compliers、argment\n")
        
    def run(self):
        self.tabWidget.setCurrentIndex(1)
        try:
            if self.rc != 0:
                self.textEdit_2.insertPlainText(f"\nexecute failed! or not create executable file:{self.out}")
                return
            else:
                self.textEdit_2.insertPlainText("\nexecuteing......")
        except AttributeError:
            pass
        
        cmd_run = f'"{self.output_file}"'
        with open("execute.cmd", "w", encoding="gbk") as f:
            f.write(get_bath_content(cmd_run))
        os.startfile("execute.cmd")
    
    def run_py(self,file):
        self.tabWidget.setCurrentIndex(1)
        with open("execute.cmd", "w", encoding="gbk") as f:
            f.write(get_bath_content(f'python "{self.fp}"'))
        
        self.out_,self.error_,self.returncode_ = _get_cmd_output("start execute.cmd")
        
        self.textEdit_2.insertPlainText(self.error_)
        
        

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())