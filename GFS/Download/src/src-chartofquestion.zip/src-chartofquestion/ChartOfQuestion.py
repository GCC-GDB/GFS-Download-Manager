"""
**************************************************
ChartOfQuestion  v2048
开发者：ZhuMi  Wang
文件：ChartOfQuestion.py
与ScanPrice联动

注意：本软件禁止倒卖，请勿抄袭，侵权必究

所用库：ttkbootstrap、matplotlib、tkinter、json、copy
*****************************************************
"""
import ttkbootstrap as ttkb                                        
from tkinter import ttk                                            
import numpy as np                                                 
from tkinter import simpledialog as inputbox
from tkinter import messagebox as msgbox
from tkinter import filedialog as fd
import json
import copy
import sys
import os 
import pandas as pd
import time

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# 全局主窗口（唯一根，所有子窗口全部绑定它）
ROOT = ttkb.Window(themename="minty")
ROOT.withdraw()  # 隐藏主根，不显示，不会生成空白窗口

# ===================== TREEVIEW 全局居中 =====================
style = ttk.Style()
style.configure("Treeview.Heading", anchor="center")
style.configure("Treeview", anchor="center")

ROOT.style.theme_use("minty")

#所有图表默认属性
graphic_attribute = {
    "pie":{
       "post" : [0.4, 0.6, 0.5, 0.5],
       "label" : ["var1","var2","var3","var4"],
       "title" : "Pie",
       "value" : [62,18,11,9],
       "color" : ["#ff0000","#ff5500","#00ff00","#0000ff"] 
    },
    "bar":{
       "post" : [0.1, 0.1, 0.3, 0.3],
       "label" : ["var1","var2","var3","var4"],
       "title" : "Bar",
       "value" : [38,38,43,8],
       "color":"#3388dd",
       "edgecolor":"#000000",
       "width":0.6
    },
    "plot":{
       "post" : [0.5, 0.1, 0.3, 0.3],
       "value" : [11,45,14,23],
       "label" : ["var1","var2","var3","var4"],
       "title" : "Plot",
       "color":"#2266dd",
       "marker":"o",
       "markersize":6,
       "linewidth":2
    },
    "multi_bar":{
       "post": [0.1, 0.5, 0.35, 0.4],
       "label": ["A","B","C","D"],
       "title": "Multi_bar",
       "value1": [20,35,28,42],
       "value2": [15,30,22,38],
       "color1":"#ff5555",
       "color2":"#5588ff",
       "width":0.4
    },
    "multi_plot":{
       "post": [0.55, 0.5, 0.35, 0.4],
       "label": ["A","B","C","D"],
       "title": "Multi_plot",
       "value1": [12,34,25,41],
       "value2": [18,28,20,35],
       "color1":"#ff3333",
       "color2":"#33aa33",
       "marker1":"o",
       "marker2":"s",
       "linewidth":2
    }
}

vb = None
isread = False

# ===================== Excel 导入 GUI 界面（你要的！） =====================
class ExcelImportWindow:
    def __init__(self):
        pass
    def main(self):
        global isread
        self.window = ttkb.Toplevel(ROOT)
        self.window.title("Excel 数据导入")
        self.window.geometry("900x600")
        self.window.resizable(False, False)

        self.isreturn = False
        isread = False
        
        # ========== 顶部：选择文件 ==========
        fr_top = ttkb.Frame(self.window)
        fr_top.pack(fill="x", padx=20, pady=10)

        ttkb.Label(fr_top, text="Excel 文件路径：", font=("微软雅黑", 11)).pack(side="left", padx=5)
        self.ent_path = ttkb.Entry(fr_top, font=("微软雅黑", 11), width=50)
        self.ent_path.pack(side="left", padx=5, fill="x", expand=True)

        ttkb.Button(
            fr_top,
            text="选择文件",
            bootstyle="primary",
            command=self.select_excel
        ).pack(side="left", padx=5)

        # ========== 选择工作表 ==========
        fr_sheet = ttkb.Frame(self.window)
        fr_sheet.pack(fill="x", padx=20, pady=5)

        ttkb.Label(fr_sheet, text="选择工作表：").pack(side="left", padx=5)
        self.cb_sheet = ttkb.Combobox(fr_sheet, state="readonly", width=20)
        self.cb_sheet.pack(side="left", padx=5)

        # ========== 预览表格 ==========
        fr_table = ttkb.Frame(self.window)
        fr_table.pack(fill="both", expand=True, padx=20, pady=10)

        ttkb.Label(fr_table, text="预览：", bootstyle="info").pack(anchor="w", pady=3)
        self.tree = ttk.Treeview(fr_table, show="headings",columns=("var","val"))
        self.tree.pack(fill="both", expand=True)
        
        self.tree.heading("var",text="变量")
        self.tree.heading("val",text="数据")

        # 滚动条
        s_y = ttkb.Scrollbar(fr_table, orient="vertical", command=self.tree.yview)
        s_x = ttkb.Scrollbar(fr_table, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=s_y.set, xscrollcommand=s_x.set)
        s_y.pack(side="right", fill="y")
        s_x.pack(side="bottom", fill="x")

        # ========== 底部按钮 ==========
        fr_btn = ttkb.Frame(self.window)
        fr_btn.pack(fill="x", padx=20, pady=10)

        ttkb.Button(
            fr_btn,
            text="导入选中数据",
            bootstyle="success",
            command=self.import_excel_data
        ).pack(side="right", padx=5)

        ttkb.Button(
            fr_btn,
            text="取消",
            bootstyle="danger",
            command=self.window.destroy
        ).pack(side="right", padx=5)

        self.check_return()
        
    
    # 选择 Excel 文件
    def select_excel(self):
        self.path = fd.askopenfilename(
            title="选择 Excel 文件",
            filetypes=[
                ("Excel 文件", "*.xlsx *.xls"),
                ("所有文件", "*.*")
            ]
        )
        if not self.path:
            return

        self.ent_path.delete(0, "end")
        self.ent_path.insert(0, self.path)

        self.df = self.convent_numpyint64_to_intger(self.ld_excel(self.path),0)
        print(self.df)
        
        for i in self.tree.get_children():
            self.tree.delete(i)
            
        for i in self.df:
            self.tree.insert("","end",values=i)
        
    
    def ld_excel(self, file_path):
        try:
            df = pd.read_excel(file_path, header=None)
            new_data = []

            for index, row in df.iterrows():
                try:
                    var = row.iloc[0]
                    val = row.iloc[1]
                    var = pd.to_datetime(var, unit="D", origin="1899-12-30").strftime("%m-%d")
                except:
                    var = str(var)
                    val = str(val)

                new_data.append([var, val])

            return list(new_data)
        except Exception as e:
            msgbox.showerror("错误",f"读取excel文件失败，可能是文件单元格式不匹配{e}")
            

    def convent_numpyint64_to_intger(self,lst,ig_u):
        try:
            out = []
            for i in lst:
                val = i[1]
                try:
                    val = int(val)
                except:
                    val = 0
                out.append([i[0], val])
            return out
        except:
            msgbox.showinfo("错误",'格式不正确，第一行为变量行，第二行为数值行')
            
            
    # 导入 Excel
    def import_excel_data(self):
        global isread
        file_path = self.ent_path.get()
        if not hasattr(self, 'path') or not self.path:
            msgbox.showwarning("提示", "请选择文件！", parent=self.window)
            return

        isread = True
        self.isreturn = True
        msgbox.showinfo("成功", "导入完成！", parent=self.window)
        self.window.destroy()
    
    def check_return(self):    
        if self.isreturn == True:
            try:
                if hasattr(self, 'df') and self.df:
                    with open("temp.json", "w", encoding="utf-8") as f:
                        json.dump({'data': self.df}, f, ensure_ascii=False, indent=4)
            except Exception as e:
                print("JSON写入失败", e)
        
        if self.window.winfo_exists():
            self.window.after(100, self.check_return)
         
        

#编辑数据类
class ChangeData():
    def __init__(self, single_chart_attr, callback_update):
        self.single_attr = single_chart_attr
        self.callback_update = callback_update
        self.type = single_chart_attr["type"]

        self.win = ttkb.Toplevel(ROOT)
        self.win.title(f"📊 编辑【{self.type}】图表参数")
        self.win.geometry("550x680")

        self.menu_bar = ttkb.Menu(self.win,tearoff=0)
        self.import_menu = ttkb.Menu(self.menu_bar,tearoff=0)
        self.import_menu.add_command(label="导入excel文件",command=self.import_excel)
        self.menu_bar.add_cascade(label="导入(I)",menu=self.import_menu)
        self.win.config(menu=self.menu_bar)

        ttkb.Label(self.win, text="位置 post(left,bottom,宽,高)", bootstyle="primary").pack(pady=4)
        fr_post = ttkb.Frame(self.win)
        fr_post.pack(pady=2)
        self.ent_post = [ttkb.Spinbox(fr_post,width=8,increment=0.1,from_=0,to=1) for _ in range(4)]
        for i,e in enumerate(self.ent_post):
            e.insert(0, f"{single_chart_attr['post'][i]}")
            e.pack(side="left",padx=3)

        ttkb.Label(self.win, text="图表标题").pack(pady=4)
        self.ent_title = ttkb.Entry(self.win, width=45)
        self.ent_title.insert(0, single_chart_attr["title"])
        self.ent_title.pack()

        ttkb.Label(self.win, text="标签 & 数值（双击单元格编辑）", bootstyle="info").pack(pady=4)
        self.tree = ttk.Treeview(self.win, columns=("label", "val"), show="headings", height=6)
        self.tree.heading("label", text="标签", anchor="center")
        self.tree.heading("val", text="数值", anchor="center")
        self.tree.column("label", width=180, anchor="center")
        self.tree.column("val", width=120, anchor="center")
        self.tree.pack(fill="x", padx=20, pady=3)
        self.tree.bind("<Double-1>", self.on_tree_edit)

        self.tree2 = None
        if self.type in ["multi_bar", "multi_plot"]:
            ttkb.Label(self.win, text="第二组数值（双击编辑）").pack(pady=2)
            self.tree2 = ttk.Treeview(self.win, columns=("val2",), show="headings", height=4)
            self.tree2.heading("val2", text="数值2", anchor="center")
            self.tree2.column("val2", width=120, anchor="center")
            self.tree2.pack(fill="x", padx=20, pady=3)
            self.tree2.bind("<Double-1>", self.on_tree2_edit)

        self.fr_special = ttkb.Frame(self.win)
        self.fr_special.pack(pady=4,fill="x",padx=20)
        self.build_special_ui()

        fr_btn = ttkb.Frame(self.win)
        fr_btn.pack(pady=10)
        ttkb.Button(fr_btn, text="➕添加项", command=self.add_row).pack(side="left",padx=4)
        ttkb.Button(fr_btn, text="➖删除选中", command=self.del_row).pack(side="left",padx=4)
        ttkb.Button(fr_btn, text="💾保存更新", bootstyle="success", command=self.save).pack(side="left",padx=4)

        self.load_tree_data()

    def import_excel(self):
        app = ExcelImportWindow()
        app.main()
        
        self.win.wait_window(app.window)

        global isread
        if isread:
            try:
                for item in self.tree.get_children():
                    self.tree.delete(item)
                
                with open("temp.json","r",encoding="utf-8") as f:
                    content = f.read().strip()
                    if not content:
                        msgbox.showerror("错误","文件为空")
                        return
                    k = json.loads(content)
                    
                datas = k['data']
                
                for row in datas:
                    self.tree.insert("", "end", values=row)
                
                isread = False
                msgbox.showinfo("成功", "数据已导入到编辑界面！", parent=self.win)
            except Exception as e:
                msgbox.showerror("错误", f"导入失败：{str(e)}", parent=self.win)
            
        
    def load_tree_data(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        labels = self.single_attr["label"]
        if self.type in ["multi_bar", "multi_plot"]:
            values = self.single_attr["value1"]
        else:
            values = self.single_attr["value"]
        for lab, val in zip(labels, values):
            self.tree.insert("", "end", values=(lab, val))

        if self.tree2:
            for item in self.tree2.get_children():
                self.tree2.delete(item)
            if "value2" in self.single_attr:
                for val in self.single_attr["value2"]:
                    self.tree2.insert("", "end", values=(val,))

    def on_tree_edit(self, event):
        item = self.tree.focus()
        col = self.tree.identify_column(event.x)
        col_idx = int(col.replace("#",""))-1
        old_val = self.tree.item(item)["values"][col_idx]
        new_val = inputbox.askstring("编辑", "输入新值：", initialvalue=old_val)
        if new_val is not None:
            vals = list(self.tree.item(item)["values"])
            vals[col_idx] = new_val
            self.tree.item(item, values=vals)

    def on_tree2_edit(self, event):
        if not self.tree2: return
        item = self.tree2.focus()
        old_val = self.tree2.item(item)["values"][0]
        new_val = inputbox.askstring("编辑", "输入第二组数值：", initialvalue=old_val)
        if new_val is not None:
            self.tree2.item(item, values=(new_val,))
            
    def build_special_ui(self):
        t = self.type
        if t=="pie":
            ttkb.Label(self.fr_special,text="饼图颜色(逗号分隔HEX)").pack()
            self.ent_color = ttkb.Entry(self.fr_special,width=45)
            self.ent_color.insert(0, ",".join(self.single_attr["color"]))
            self.ent_color.pack()
        elif t=="bar":
            ttkb.Label(self.fr_special,text="柱子颜色｜边框颜色｜宽度").pack()
            self.ent_color = ttkb.Entry(self.fr_special,width=20); self.ent_color.insert(0,self.single_attr["color"]); self.ent_color.pack()
            self.ent_ec = ttkb.Entry(self.fr_special,width=20); self.ent_ec.insert(0,self.single_attr["edgecolor"]); self.ent_ec.pack()
            self.ent_w = ttkb.Entry(self.fr_special,width=10); self.ent_w.insert(0,self.single_attr["width"]); self.ent_w.pack()
        elif t=="plot":
            ttkb.Label(self.fr_special,text="线条颜色｜线宽｜标记｜标记大小").pack()
            self.ent_color = ttkb.Entry(self.fr_special,width=20); self.ent_color.insert(0,self.single_attr["color"]); self.ent_color.pack()
            self.ent_lw = ttkb.Entry(self.fr_special,width=10); self.ent_lw.insert(0,self.single_attr["linewidth"]); self.ent_lw.pack()
            self.ent_mk = ttkb.Entry(self.fr_special,width=10); self.ent_mk.insert(0,self.single_attr["marker"]); self.ent_mk.pack()
            self.ent_ms = ttkb.Entry(self.fr_special,width=10); self.ent_ms.insert(0,self.single_attr["markersize"]); self.ent_ms.pack()
        elif t=="multi_bar":
            ttkb.Label(self.fr_special,text="第一组颜色｜第二组颜色｜宽度").pack()
            self.ent_c1 = ttkb.Entry(self.fr_special,width=20); self.ent_c1.insert(0,self.single_attr["color1"]); self.ent_c1.pack()
            self.ent_c2 = ttkb.Entry(self.fr_special,width=20); self.ent_c2.insert(0,self.single_attr["color2"]); self.ent_c2.pack()
            self.ent_w = ttkb.Entry(self.fr_special,width=10); self.ent_w.insert(0,self.single_attr["width"]); self.ent_w.pack()
        elif t=="multi_plot":
            ttkb.Label(self.fr_special,text="第一组颜色｜第二组颜色｜线宽").pack()
            self.ent_c1 = ttkb.Entry(self.fr_special,width=20); self.ent_c1.insert(0,self.single_attr["color1"]); self.ent_c1.pack()
            self.ent_c2 = ttkb.Entry(self.fr_special,width=20); self.ent_c2.insert(0,self.single_attr["color2"]); self.ent_c2.pack()
            self.ent_lw = ttkb.Entry(self.fr_special,width=10); self.ent_lw.insert(0,self.single_attr["linewidth"]); self.ent_lw.pack()
            self.ent_m1 = ttkb.Entry(self.fr_special,width=10); self.ent_m1.insert(0,self.single_attr["marker1"]); self.ent_m1.pack()
            self.ent_m2 = ttkb.Entry(self.fr_special,width=10); self.ent_m2.insert(0,self.single_attr["marker2"]); self.ent_m2.pack()

    def add_row(self):
        self.tree.insert("", "end", values=("新标签", 0))
        if self.tree2:
            self.tree2.insert("", "end", values=(0,))

    def del_row(self):
        sel = self.tree.selection()
        if sel:
            self.tree.delete(sel)
            if self.tree2:
                sel2 = self.tree2.selection()
                if sel2:
                    self.tree2.delete(sel2)

    def save(self):
        try:
            self.single_attr["post"] = [float(e.get()) for e in self.ent_post]
            self.single_attr["title"] = self.ent_title.get()

            labels, vals = [], []
            for item in self.tree.get_children():
                lab, val = self.tree.item(item)["values"]
                labels.append(lab)
                vals.append(float(val))
            self.single_attr["label"] = labels

            if self.type in ["multi_bar", "multi_plot"]:
                self.single_attr["value1"] = vals
                vals2 = []
                for item in self.tree2.get_children():
                    vals2.append(float(self.tree2.item(item)["values"][0]))
                self.single_attr["value2"] = vals2
            else:
                self.single_attr["value"] = vals
            
            for p in self.single_attr["post"]:
                if not (0 <= p <= 1):
                    msgbox.showerror("参数错误", "位置必须在 0~1 之间", parent=self.win)
                    return

            if self.type=="pie":
                self.single_attr["color"] = self.ent_color.get().split(",")
            elif self.type=="bar":
                self.single_attr["color"] = self.ent_color.get()
                self.single_attr["edgecolor"] = self.ent_ec.get()
                self.single_attr["width"] = float(self.ent_w.get())
            elif self.type=="plot":
                self.single_attr["color"] = self.ent_color.get()
                self.single_attr["linewidth"] = float(self.ent_lw.get())
                self.single_attr["marker"] = self.ent_mk.get()
                self.single_attr["markersize"] = float(self.ent_ms.get())
            elif self.type=="multi_bar":
                self.single_attr["color1"] = self.ent_c1.get()
                self.single_attr["color2"] = self.ent_c2.get()
                self.single_attr["width"] = float(self.ent_w.get())
            elif self.type=="multi_plot":
                self.single_attr["color1"] = self.ent_c1.get()
                self.single_attr["color2"] = self.ent_c2.get()
                self.single_attr["linewidth"] = float(self.ent_lw.get())
                self.single_attr["marker1"] = self.ent_m1.get()
                self.single_attr["marker2"] = self.ent_m2.get()

            self.callback_update()
            self.win.destroy()
        except Exception as e:
            msgbox.showerror("参数错误", f"格式异常：{str(e)}", parent=self.win)
            

#主程序GUI
class GraphicUserInterFace():
    def __init__(self,file=None):
        self.root = ttkb.Toplevel(ROOT)
        self.root.geometry("1366x768")
        self.root.title("ChartOfQuestion")
        self.root.protocol("WM_DELETE_WINDOW",self.ext)
        
        
        plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'PingFang SC']
        plt.rcParams['axes.unicode_minus'] = False

        self.fp = None
        self.fig = Figure(figsize=(10, 6), dpi=100)
        self.clipboard = None
        self.undo_stack = []
        self.redo_stack = []
        self.selected_chart_index = -1
        self.is_save = False
        self.all_charts = []
        self.all_charts_attribute = []
        self.ischange = True
        self.chart_frame = ttkb.Frame(self.root,width=1920,height=1080)
        self.chart_frame.place(x=0,y=0)
        
        self.dragging = False
        self.selected_ax = None
        self.ix = 0
        self.iy = 0
        
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.chart_frame)
        self.widget = self.canvas.get_tk_widget()
        self.widget.place(x=0,y=0)
        self.widget.config(width=1920, height=1080)

        self.canvas.mpl_connect('button_press_event', self.on_press)
        self.canvas.mpl_connect('motion_notify_event', self.on_motion)
        self.canvas.mpl_connect('button_release_event', self.on_release)
        self.canvas.mpl_connect('key_press_event', self.on_key_press)

        self.menubar = ttkb.Menu(self.root, tearoff=0)
        self.file_menu = ttkb.Menu(self.menubar, tearoff=0)
        self.file_menu.add_command(label="新建图表画布", command=lambda:GraphicUserInterFace())
        self.file_menu.add_command(label="打开(O)", command=lambda:self.open_file_type_coqfle())
        self.file_menu.add_command(label="保存(S)", command=lambda:self.save())
        self.file_menu.add_command(label="另存为(A)", command=lambda:self.saveas())
        self.file_menu.add_separator()
        self.file_menu.add_command(label="打开excel文件", command=None)
        self.file_menu.add_command(label="退出(X)", command=self.ext)
        self.menubar.add_cascade(label="文件(F)", menu=self.file_menu)

        self.tools_menu = ttkb.Menu(self.menubar, tearoff=0)
        self.tools_menu.add_command(label="遍历所有图表(F)", command=self.list_all_charts)
        self.tools_menu.add_command(label="数据编辑(E)", command=self.editdata)
        
        self.menubar.add_cascade(label="工具(T)", menu=self.tools_menu)
        
        self.edit_menu = ttkb.Menu(self.menubar,tearoff=0)
        self.edit_menu.add_command(label="复制(C)", command=self.copy_chart)
        self.edit_menu.add_command(label="粘贴(P)", command=self.paste_chart)
        self.edit_menu.add_command(label="剪切(X)", command=self.cut_chart)
        self.edit_menu.add_separator()
        self.edit_menu.add_command(label="撤销(U)", command=self.undo)
        self.edit_menu.add_command(label="重做(R)", command=self.redo)
        self.edit_menu.add_command(label="删除(D)", command=self.delete)
        self.menubar.add_cascade(label="编辑(E)", menu=self.edit_menu)
        
        self.insert_menu = ttkb.Menu(self.menubar, tearoff=0)
        self.insert_menu.add_command(label="扇形统计图", command=lambda:self.add_pie(graphic_attribute))
        self.insert_menu.add_command(label="条形统计图", command=lambda:self.add_bar(graphic_attribute))
        self.insert_menu.add_command(label="折线统计图", command=lambda:self.add_plot(graphic_attribute))
        self.insert_menu.add_command(label="复式柱状图", command=lambda:self.add_multi_bar(graphic_attribute))
        self.insert_menu.add_command(label="复式折线图", command=lambda:self.add_multi_plot(graphic_attribute))
        self.menubar.add_cascade(label="插入(I)", menu=self.insert_menu)
        self.root.config(menu=self.menubar)

        if not file == None:
            try:
                with open(file,"r",encoding="utf-8") as f:
                    k = json.load(f)
                
                self.fp = file
                self.all_charts_attribute = k["chartsa"]
                self.refresh_all()
                
                self.is_save = True
                self.root.title("ChartOfQuestion -- {}".format(self.fp))
            except Exception as e:
                msgbox.showerror("错误",f"加载文件失败:{e}")
        
    def on_key_press(self,event):
        if event.key == 'ctrl+c':
            self.copy_chart()
        elif event.key == 'ctrl+v':
            self.paste_chart()
        elif event.key == 'ctrl+x':
            self.cut_chart()
        elif event.key == 'ctrl+z':
            self.undo()
        elif event.key == 'ctrl+y':
            self.redo()
        elif event.key == 'ctrl+e':
            self.editdata()
        elif event.key == 'ctrl+m':
            self.saveas()
        elif event.key == 'ctrl+s':
            self.save()
        elif event.key == 'ctrl+o':
            self.open_file_type_coqfle()
        elif event.key == 'alt+d':
            self.delete()
        elif event.key == 'alt+p':
            self.add_pie(graphic_attribute)
        elif event.key == 'alt+l':
            self.add_plot(graphic_attribute)
        elif event.key == 'alt+b':
            self.add_bar(graphic_attribute)
        elif event.key == 'alt+q':
            self.add_multi_bar(graphic_attribute)
        elif event.key == 'alt+m':
            self.add_multi_plot(graphic_attribute)
    def editdata(self):
        if self.selected_chart_index == -1:
            msgbox.showwarning("提示", "请先点击选中一个图表！")
            return
        self.clipboard = copy.deepcopy(self.all_charts_attribute[self.selected_chart_index])
        ChangeData(self.all_charts_attribute[self.selected_chart_index], self.refresh_all)
                
    def save_state(self):
        state = copy.deepcopy(self.all_charts_attribute)
        self.undo_stack.append(state)
        self.redo_stack.clear()

    def list_all_charts(self):
        print("\n" + "="*50)
        print("📋 遍历所有图表")
        print("="*50)
        for i, attr in enumerate(self.all_charts_attribute):
            print(f"\n🔹 第 {i+1} 个图表")
            print(f"类型：{attr['type']}")
            print(f"标题：{attr['title']}")
            print(f"位置：{attr['post']}")
            print(f"标签：{attr['label']}")
            print(f"数值：{attr.get('value',attr.get('value1'))}")
        print(f"\n✅ 总共有：{len(self.all_charts_attribute)} 个图表\n")

    def on_press(self, event):
        if event.inaxes is None:
            self.selected_chart_index = -1
            return
        try:
            self.selected_chart_index = self.all_charts.index(event.inaxes)
        except ValueError:
            self.selected_chart_index = -1
            return

        self.dragging = True
        self.selected_ax = event.inaxes
        self.ix = event.x - self.selected_ax.get_position().x0 * self.widget.winfo_width()
        self.iy = event.y - self.selected_ax.get_position().y0 * self.widget.winfo_height()

    def on_motion(self, event):
        if not self.dragging or self.selected_ax is None: 
            return
        w = self.widget.winfo_width()
        h = self.widget.winfo_height()
        new_x = (event.x - self.ix) / w
        new_y = (event.y - self.iy) / h
        pos = self.selected_ax.get_position()
        if 0 <= new_x <= 1 and 0 <= new_y <= 1:
            self.selected_ax.set_position([new_x, new_y, pos.width, pos.height])
            self.canvas.draw()
            idx = self.all_charts.index(self.selected_ax)
            self.all_charts_attribute[idx]["post"] = [new_x, new_y, pos.width, pos.height]

    def on_release(self, event):
        self.dragging = False
        self.selected_ax = None

    def refresh_all(self):
        self.fig.clf()
        self.all_charts.clear()
        for attr in self.all_charts_attribute:
            if attr["type"]=="pie":
                ax = self.fig.add_axes(attr["post"])
                ax.pie(attr["value"], labels=attr["label"], autopct="%1.1f%%", colors=attr["color"])
                ax.set_title(attr["title"])
                self.all_charts.append(ax)
            elif attr["type"]=="bar":
                ax = self.fig.add_axes(attr["post"])
                ax.bar(x=attr["label"], height=attr["value"], color=attr["color"], edgecolor=attr["edgecolor"], width=attr["width"])
                ax.set_title(attr["title"])
                self.all_charts.append(ax)
                ax.tick_params(axis="x", rotation=45, pad=6)
                plt.setp(ax.get_xticklabels(), ha="right")
            elif attr["type"]=="plot":
                ax = self.fig.add_axes(attr["post"])
                ax.plot(attr["label"], attr["value"], color=attr["color"], marker=attr["marker"], markersize=attr["markersize"], linewidth=attr["linewidth"])
                ax.set_title(attr["title"])
                self.all_charts.append(ax)
                ax.tick_params(axis="x", rotation=45, pad=6)
                plt.setp(ax.get_xticklabels(), ha="right")
            elif attr["type"]=="multi_bar":
                ax = self.fig.add_axes(attr["post"])
                x = np.arange(len(attr["label"]))
                ax.bar(x-0.2, attr["value1"], width=attr["width"], color=attr["color1"])
                ax.bar(x+0.2, attr["value2"], width=attr["width"], color=attr["color2"])
                ax.set_xticks(x)
                ax.set_xticklabels(attr["label"])
                ax.set_title(attr["title"])
                self.all_charts.append(ax)
                ax.tick_params(axis="x", rotation=45, pad=6)
                plt.setp(ax.get_xticklabels(), ha="right")
            elif attr["type"]=="multi_plot":
                ax = self.fig.add_axes(attr["post"])
                ax.plot(attr["label"], attr["value1"], color=attr["color1"], marker=attr["marker1"], linewidth=attr["linewidth"])
                ax.plot(attr["label"], attr["value2"], color=attr["color2"], marker=attr["marker2"], linewidth=attr["linewidth"])
                ax.set_title(attr["title"])
                self.all_charts.append(ax)
                ax.tick_params(axis="x", rotation=45, pad=6)
                plt.setp(ax.get_xticklabels(), ha="right")
        
        self.ischange = True
        self.canvas.draw_idle()

    def copy_chart(self):
        if self.selected_chart_index == -1:
            msgbox.showwarning("提示", "请先点击选中一个图表！")
            return
        self.clipboard = copy.deepcopy(self.all_charts_attribute[self.selected_chart_index])
        msgbox.showinfo("成功", "图表已复制！")

    def paste_chart(self):
        if not self.clipboard:
            msgbox.showwarning("提示", "剪贴板为空，请先复制！")
            return
        
        self.save_state()
        new_chart = copy.deepcopy(self.clipboard)
        new_chart["post"][0] += 0.05
        new_chart["post"][1] += 0.05
        new_chart["title"] += " (复制)"
        
        self.all_charts_attribute.append(new_chart)
        self.refresh_all()
        msgbox.showinfo("成功", "图表已粘贴！")

    def cut_chart(self):
        if self.selected_chart_index == -1:
            msgbox.showwarning("提示", "请先点击选中一个图表！")
            return
        
        self.save_state()
        self.clipboard = copy.deepcopy(self.all_charts_attribute[self.selected_chart_index])
        del self.all_charts_attribute[self.selected_chart_index]
        self.selected_chart_index = -1
        self.refresh_all()
        msgbox.showinfo("成功", "图表已剪切！")

    def undo(self):
        if not self.undo_stack:
            msgbox.showwarning("提示", "无操作可撤销！")
            return
        
        current_state = copy.deepcopy(self.all_charts_attribute)
        self.redo_stack.append(current_state)
        self.all_charts_attribute = self.undo_stack.pop()
        self.refresh_all()

    def redo(self):
        if not self.redo_stack:
            msgbox.showwarning("提示", "无操作可重做！")
            return
        
        current_state = copy.deepcopy(self.all_charts_attribute)
        self.undo_stack.append(current_state)
        self.all_charts_attribute = self.redo_stack.pop()
        self.refresh_all()
        
    def saveas(self):
        write_d = {
            "chartsa": self.all_charts_attribute
        }

        self.export_type = ttkb.StringVar()
        self.fp = fd.asksaveasfilename(
            title="另存为",
            filetypes=(
                ["图表文件", "*.coqfle"],
                ["Json配置文件", "*.json"],
                ["PNG图片", "*.png"]
            ),
            typevariable=self.export_type
        )

        if not self.fp:
            return

        idx = self.export_type.get()

        if idx in ["图表文件", "Json配置文件"]:
            try:
                with open(self.fp, "w", encoding="utf-8") as f:
                    json.dump(write_d, f, ensure_ascii=False, indent=4)
                self.is_save = True
                self.root.title("ChartOfQuestion -- {}".format(self.fp))
                self.ischange = False
                msgbox.showinfo("成功", "文件已保存！")
            except Exception as e:
                msgbox.showerror("保存失败", str(e))

        elif idx == "PNG图片":
            if not self.fp.lower().endswith(".png"):
                self.fp += ".png"

            if not self.all_charts_attribute:
                if not msgbox.askyesno("注意","画布为空，确定导出空图片吗？"):
                    return
            try:
                self.fig.savefig(
                    self.fp,
                    dpi=300,
                    bbox_inches="tight",
                    pad_inches=0.1
                )
                msgbox.showinfo("成功", f"图片已导出：\n{self.fp}")
            except Exception as e:
                msgbox.showerror("导出图片失败", str(e))
                
    def delete(self):
        if self.selected_chart_index <0:
            msgbox.showwarning("提示","请选中图表")
            return
        del self.all_charts_attribute[self.selected_chart_index]
        self.selected_chart_index = -1
        self.refresh_all()
        
    def save(self):
        if self.is_save == False:
            self.saveas()
        else:
            write_d = {
                "chartsa" : self.all_charts_attribute
            }
            with open(self.fp,"w",encoding="utf-8") as f:
                json.dump(write_d,f,ensure_ascii=False, indent=4)
            
            self.ischange = False
    def open_file_type_coqfle(self):
        self.fp = fd.askopenfilename(title="打开文件",filetypes=(["图表文件","*.coqfle"],["Json配置文件","*.json"]))
        
        try:
            if self.fp == '':
                return
            with open(self.fp,"r",encoding="utf-8") as f:
                k = json.load(f)
            
            self.all_charts_attribute = k["chartsa"]
            self.refresh_all()
            
            self.is_save = True
            self.root.title("ChartOfQuestion -- {}".format(self.fp))
            
        
        except json.JSONDecodeError:
            msgbox.showerror("错误","读取文件时遇到问题：未知文件格式\n请检查文件格式，文件是否损坏")
        except PermissionError:
            msgbox.showerror("错误","读取文件时遇到问题：权限不足")
        except FileNotFoundError:
            msgbox.showerror("错误","读取文件时遇到问题：文件未找到")
        except Exception as e:
            msgbox.showerror("错误",f"读取文件时遇到问题：未知错误：{e}")

    def add_pie(self, attribute):
        self.save_state()
        ax = self.fig.add_axes(attribute["pie"]['post'])
        values = attribute["pie"]['value']
        ax.pie(values, labels=attribute["pie"]['label'], autopct='%1.1f%%', colors=attribute["pie"]['color'])
        ax.set_title(attribute["pie"]['title'])
        chart_attr = {"type":"pie",**attribute["pie"]}
        self.all_charts_attribute.append(chart_attr)
        self.all_charts.append(ax)
        self.refresh_all()

    def add_bar(self, attribute):
        self.save_state()
        ax = self.fig.add_axes(attribute["bar"]['post'])
        ax.bar(height=attribute["bar"]['value'], x=attribute["bar"]['label'], color=attribute["bar"]["color"], edgecolor=attribute["bar"]["edgecolor"], width=attribute["bar"]["width"])
        ax.set_title(attribute["bar"]['title'])
        ax.tick_params(axis="x", rotation=45, pad=6)
        plt.setp(ax.get_xticklabels(), ha="right")
        chart_attr = {"type":"bar",**attribute["bar"]}
        self.all_charts_attribute.append(chart_attr)
        self.all_charts.append(ax)
        self.refresh_all()
        

    def add_plot(self, attribute):
        self.save_state()
        ax = self.fig.add_axes(attribute["plot"]['post'])
        ax.plot(attribute["plot"]['label'], attribute["plot"]['value'], color=attribute["plot"]["color"], marker=attribute["plot"]["marker"], markersize=attribute["plot"]["markersize"], linewidth=attribute["plot"]["linewidth"])
        ax.set_title(attribute["plot"]['title'])
        ax.tick_params(axis="x", rotation=45, pad=6)
        plt.setp(ax.get_xticklabels(), ha="right")
        chart_attr = {"type":"plot",**attribute["plot"]}
        self.all_charts_attribute.append(chart_attr)
        self.all_charts.append(ax)
        self.refresh_all()

    def add_multi_bar(self, attribute):
        self.save_state()
        ax = self.fig.add_axes(attribute["multi_bar"]["post"])
        x = np.arange(len(attribute["multi_bar"]["label"]))
        ax.bar(x - 0.2, attribute["multi_bar"]["value1"], width=attribute["multi_bar"]["width"], color=attribute["multi_bar"]["color1"])
        ax.bar(x + 0.2, attribute["multi_bar"]["value2"], width=attribute["multi_bar"]["width"], color=attribute["multi_bar"]["color2"])
        ax.set_xticks(x)
        ax.set_xticklabels(attribute["multi_bar"]["label"])
        ax.set_title(attribute["multi_bar"]["title"])
        ax.tick_params(axis="x", rotation=45, pad=6)
        plt.setp(ax.get_xticklabels(), ha="right")
        chart_attr = {"type":"multi_bar", **attribute["multi_bar"]}
        self.all_charts_attribute.append(chart_attr)
        self.all_charts.append(ax)
        self.refresh_all()

    def add_multi_plot(self, attribute):
        self.save_state()
        ax = self.fig.add_axes(attribute["multi_plot"]["post"])
        ax.plot(attribute["multi_plot"]["label"], attribute["multi_plot"]["value1"], color=attribute["multi_plot"]["color1"], marker=attribute["multi_plot"]["marker1"], linewidth=attribute["multi_plot"]["linewidth"])
        ax.plot(attribute["multi_plot"]["label"], attribute["multi_plot"]["value2"], color=attribute["multi_plot"]["color2"], marker=attribute["multi_plot"]["marker2"], linewidth=attribute["multi_plot"]["linewidth"])
        ax.set_title(attribute["multi_plot"]['title'])
        chart_attr = {"type":"multi_plot", **attribute["multi_plot"]}
        self.all_charts_attribute.append(chart_attr)
        self.all_charts.append(ax)
        self.refresh_all()

    def ext(self):
        if self.ischange == True:
            p = msgbox.askyesnocancel("你确定吗？",f"文件{self.fp}未保存，是否保存后退出？")
            if p == True:
                self.save()
                self.root.destroy()
            elif p == False:
                self.root.destroy()
        else:
            self.root.destroy()

# 启动界面
class StartInterFace():
    def __init__(self):
        self.root = ttkb.Toplevel(ROOT)
        self.root.geometry("1366x768")
        self.root.title("ChartOfQuestion -- 开始")
        self.root.protocol("WM_DELETE_WINDOW",self.ext)
        
        ttkb.Label(self.root,text="ChartOfQuestion",font=("微软雅黑",22,"normal")).place(x=40,y=50)
        ttkb.Label(self.root,text="版本：2048 开发团队：Invalid Nexus 开发者：Zhumi Wang，与ScanPrice联动").place(x=40,y=120)
        ttkb.Label(self.root,text="版权所有@Invaild Nexus，禁止抄袭，侵权必究").place(x=40,y=140)
        ttkb.Label(self.root,text="如果有疑问，请发送邮件到binrary@qq.com").place(x=40,y=160)
        ttkb.Label(self.root,text="新建或打开一个文件：").place(x=40,y=250)
        
        ttkb.Button(self.root,bootstyle="primary-link",text="📄新建图表文件",command=GraphicUserInterFace).place(x=30,y=330)
        ttkb.Button(self.root,bootstyle="primary-link",text="📂打开图表文件",command=self.openf).place(x=30,y=360)
        ttkb.Button(self.root,bootstyle="secondary-link",text="📂打开excel并转化成图表").place(x=30,y=390)
    def ext(self):
        ROOT.quit()
        sys.exit()

    def openf(self):
        fp = fd.askopenfilename(title="打开文件",filetypes=(["图表文件","*.coqfle"],["Json配置文件","*.json"]))
        GraphicUserInterFace(fp)
# --------------------------
# 最终启动
# --------------------------

if __name__ == '__main__':
    StartInterFace()
    ROOT.mainloop()